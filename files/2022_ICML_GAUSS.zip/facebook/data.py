from torch_geometric.datasets import FacebookPagePage
import torch
import random
import os
import torch_geometric.transforms as T

def load_dataset(device='cuda'):
    dataset = FacebookPagePage(os.path.expanduser("~/guancy/datasets/pyg"), transform=T.NormalizeFeatures())
    data = dataset[0]
    data = data.to(device)

    print('num features', data.x.size(1))
    print('num classes', dataset.num_classes)

    if not os.path.exists(f"models/facebook/split.bin"):
        # fix random seed of train/val/test split
        random.seed(2022)
        masks = list(range(data.num_nodes))
        random.shuffle(masks)
        fold = int(data.num_nodes * 0.1)
        train_idx = masks[:fold * 6]
        val_idx = masks[fold * 6: fold * 8]
        test_idx = masks[fold * 8:]
        split_idx = {
            'train': torch.tensor(train_idx).long(),
            'valid': torch.tensor(val_idx).long(),
            'test': torch.tensor(test_idx).long()
        }
        torch.save(split_idx, f"models/facebook/split.bin")
    else:
        split_idx = torch.load(f"models/facebook/split.bin")

    for key in split_idx: split_idx[key] = split_idx[key].to(device)

    train_idx = split_idx['train'].to(device)
    valid_idx = split_idx['valid'].to(device)
    test_idx = split_idx['test'].to(device)
    return dataset, data, train_idx, valid_idx, test_idx, split_idx