import os
import numpy as np
import torch
import random

from .logger import Logger
from .dataset import load_dataset

def set_seed(seed=2022):
    os.environ['PYTHONHASHSEED'] = str(seed)
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

__all__ = ["Logger", "set_seed", "load_dataset"]
