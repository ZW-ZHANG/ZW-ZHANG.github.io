import os
import random
import torch_geometric.transforms as T
from ogb.nodeproppred import PygNodePropPredDataset
from torch_geometric.datasets import Coauthor
import torch
import torch_sparse
from torch_geometric.datasets import FacebookPagePage

def load_dataset(name, device, path="dataset"):
    if name == 'arxiv':
        return load_arxiv(device, path)
    if name in ['CS', 'Physics']:
        return load_coauthor(name, device, path)
    if name == 'facebook':
        return load_facebook(device, path)

def load_arxiv(device, path):
    dataset = PygNodePropPredDataset(name='ogbn-arxiv', root=os.path.join(path, "arxiv"), transform=T.ToSparseTensor())
    
    data = dataset[0]
    data.adj_t = data.adj_t.to_symmetric()
    data = data.to(device)
    
    x = data.x
    x = x.to(device)
    data.adj_t = data.adj_t.to(device)
    y = data.y.to(device)[:, 0]
    
    split_idx = dataset.get_idx_split()
    train_idx = split_idx['train'].to(device)
    valid_idx = split_idx['valid'].to(device)
    test_idx = split_idx['test'].to(device)
    return data, x, y, train_idx, valid_idx, test_idx, dataset.num_classes

def load_coauthor(name, device, path):
    dataset = Coauthor(os.path.join(path, "coauthor"), name=name, transform=T.NormalizeFeatures())

    data = dataset[0]
    data = data.to(device)
    split_folder = os.path.join(path, "split", f"{name}_split.bin")
    if not os.path.exists(split_folder):
        print('split unfound, will create one randomly...')
        # fix random seed of train/val/test split
        random.seed(2022)
        masks = list(range(data.num_nodes))
        random.shuffle(masks)
        fold = int(data.num_nodes * 0.1)
        train_idx = masks[:fold * 6]
        val_idx = masks[fold * 6: fold * 8]
        test_idx = masks[fold * 8:]
        split_idx = {
            'train': torch.tensor(train_idx).long(),
            'valid': torch.tensor(val_idx).long(),
            'test': torch.tensor(test_idx).long()
        }
        torch.save(split_idx, split_folder)
    else:
        split_idx = torch.load(split_folder)
    
    for key in split_idx: split_idx[key] = split_idx[key].to(device)

    train_idx = split_idx['train'].to(device)
    valid_idx = split_idx['valid'].to(device)
    test_idx = split_idx['test'].to(device)
    x = data.x
    data.adj_t = data.edge_index
    return data, data.x, data.y, train_idx, valid_idx, test_idx, dataset.num_classes

def load_facebook(device, path):
    dataset = FacebookPagePage(os.path.join(path, "facebook"), transform=T.NormalizeFeatures())

    data = dataset[0]
    data = data.to(device)

    split_folder = os.path.join(path, "split", "facebook_split.bin")
    if not os.path.exists(split_folder):
        print('split unfound, will create one randomly...')
        # fix random seed of train/val/test split
        random.seed(2022)
        masks = list(range(data.num_nodes))
        random.shuffle(masks)
        fold = int(data.num_nodes * 0.1)
        train_idx = masks[:fold * 6]
        val_idx = masks[fold * 6: fold * 8]
        test_idx = masks[fold * 8:]
        split_idx = {
            'train': torch.tensor(train_idx).long(),
            'valid': torch.tensor(val_idx).long(),
            'test': torch.tensor(test_idx).long()
        }
        torch.save(split_idx, split_folder)
    else:
        split_idx = torch.load(split_folder)
    
    for key in split_idx: split_idx[key] = split_idx[key].to(device)

    train_idx = split_idx['train'].to(device)
    valid_idx = split_idx['valid'].to(device)
    test_idx = split_idx['test'].to(device)
    data.adj_t = data.edge_index
    return data, data.x, data.y, train_idx, valid_idx, test_idx, dataset.num_classes
