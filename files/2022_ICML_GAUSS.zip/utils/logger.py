import torch


class Logger(object):
    def __init__(self, runs, info=None):
        self.info = info
        self.results = [[] for _ in range(runs)]
    
    def set_path(self, path):
        self.path = path

    def add_result(self, run, result):
        assert len(result) == 3
        assert run >= 0 and run < len(self.results)
        self.results[run].append(result)

    def print_statistics(self, run=None, print_all=True):
        
        def log(strs):
            print(strs)
            if hasattr(self, 'path') and self.path is not None:
                open(self.path, 'a').write(strs + '\n')

        if run is not None:
            result = 100 * torch.tensor(self.results[run])
            argmax = result[:, 1].argmax().item()
            log(f'Run {run + 1:02d}:')
            log(f'Highest Train: {result[:, 0].max():.2f}')
            log(f'Highest Valid: {result[:, 1].max():.2f}')
            log(f'  Final Train: {result[argmax, 0]:.2f}')
            log(f'   Final Test: {result[argmax, 2]:.2f}')
        else:
            result = 100 * torch.tensor(self.results)

            best_results = []
            for r in result:
                train1 = r[:, 0].max().item()
                valid = r[:, 1].max().item()
                train2 = r[r[:, 1].argmax(), 0].item()
                test = r[r[:, 1].argmax(), 2].item()
                best_results.append((train1, valid, train2, test))

            best_result = torch.tensor(best_results)
            
            log(f'All runs:')
            if print_all:
                r = best_result[:, 0]
                log(f'Highest Train: {r.mean():.2f} ± {r.std():.2f}')
                r = best_result[:, 1]
                log(f'Highest Valid: {r.mean():.2f} ± {r.std():.2f}')
                r = best_result[:, 2]
                log(f'  Final Train: {r.mean():.2f} ± {r.std():.2f}')
            r = best_result[:, 3]
            log(f'   Final Test: {r.mean():.2f} ± {r.std():.2f}')

