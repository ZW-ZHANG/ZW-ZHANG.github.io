import argparse

import torch
import torch.nn.functional as F

from torch_geometric.loader import ClusterData, ClusterLoader, NeighborSampler
from .supernet import Supernet
from torch_geometric.utils import to_undirected
from torch_sparse import SparseTensor

import os
import time

from ogb.nodeproppred import PygNodePropPredDataset, Evaluator

from utils import Logger, CorrectAndSmooth

def train(model, loader, optimizer, device, arch):
    model.train()

    total_loss = total_examples = 0
    total_correct = total_examples = 0
    for data in loader:
        data = data.to(device)
        if data.train_mask.sum() == 0:
            continue
        optimizer.zero_grad()
        out = model(data.x, data.edge_index, arch)[data.train_mask]
        y = data.y.squeeze(1)[data.train_mask]
        loss = F.nll_loss(out, y)
        loss.backward()
        optimizer.step()

        num_examples = data.train_mask.sum().item()
        total_loss += loss.item() * num_examples
        total_examples += num_examples

        total_correct += out.argmax(dim=-1).eq(y).sum().item()

    return total_loss / total_examples, total_correct / total_examples


@torch.no_grad()
def test(model, data, evaluator, subgraph_loader, device, arch):
    model.eval()

    out = model.inference(data.x, subgraph_loader, device, arch)

    y_true = data.y
    y_pred = out.argmax(dim=-1, keepdim=True)

    train_acc = evaluator.eval({
        'y_true': y_true[data.train_mask],
        'y_pred': y_pred[data.train_mask]
    })['acc']
    valid_acc = evaluator.eval({
        'y_true': y_true[data.valid_mask],
        'y_pred': y_pred[data.valid_mask]
    })['acc']
    test_acc = evaluator.eval({
        'y_true': y_true[data.test_mask],
        'y_pred': y_pred[data.test_mask]
    })['acc']

    return out, (train_acc, valid_acc, test_acc)

def process_adj(data):
    N = data.num_nodes
    data.edge_index = to_undirected(data.edge_index, data.num_nodes)

    row, col = data.edge_index

    adj = SparseTensor(row=row, col=col, sparse_sizes=(N, N))
    adj = adj.set_diag()
    deg = adj.sum(dim=1).to(torch.float)
    deg_inv_sqrt = deg.pow(-0.5)
    deg_inv_sqrt[deg_inv_sqrt == float('inf')] = 0
    adj = deg_inv_sqrt.view(-1, 1) * adj * deg_inv_sqrt.view(1, -1)
    return adj

@torch.no_grad()
def test_out(out, data, split_idx, evaluator):

    y_pred = out.argmax(dim=-1, keepdim=True)

    train_acc = evaluator.eval({
        'y_true': data.y[split_idx['train']],
        'y_pred': y_pred[split_idx['train']],
    })['acc']
    valid_acc = evaluator.eval({
        'y_true': data.y[split_idx['valid']],
        'y_pred': y_pred[split_idx['valid']],
    })['acc']
    test_acc = evaluator.eval({
        'y_true': data.y[split_idx['test']],
        'y_pred': y_pred[split_idx['test']],
    })['acc']

    return train_acc, valid_acc, test_acc, out

def main():
    parser = argparse.ArgumentParser(description='OGBN-Products (Cluster-GCN)')
    parser.add_argument('--device', type=int, default=0)
    parser.add_argument('--log_steps', type=int, default=1)
    parser.add_argument('--num_partitions', type=int, default=15000)
    parser.add_argument('--num_workers', type=int, default=12)
    parser.add_argument('--num_layers', type=int, default=3)
    parser.add_argument('--hidden_channels', type=int, default=256)
    parser.add_argument('--dropout', type=float, default=0.5)
    parser.add_argument('--batch_size', type=int, default=32)
    parser.add_argument('--lr', type=float, default=0.001)
    parser.add_argument('--epochs', type=int, default=50)
    parser.add_argument('--node2vec', action='store_true')
    parser.add_argument('--eval_steps', type=int, default=5)
    parser.add_argument('--begin_eval', type=int, default=20)
    parser.add_argument('--runs', type=int, default=10)
    # parser.add_argument('--cs', action='store_true')
    parser.add_argument('--arch', type=str, default=str(['sage', 'sage', 'sage', 'sage']))
    parser.add_argument('--no-track', action='store_true')

    args = parser.parse_args()

    # names
    arch = eval(args.arch)
    
    log_path = os.path.join('./logs/products/retrain', f'{"-".join(arch)}-{args.node2vec}.log')
    os.makedirs('./logs/products/retrain', exist_ok=True)

    def log(strs):
        strs = str(strs)
        print(strs)
        open(log_path, 'a').write(strs + '\n')

    log(args)
    device = f'cuda:{args.device}' if torch.cuda.is_available() else 'cpu'
    device = torch.device(device)

    dataset = PygNodePropPredDataset(name='ogbn-products', root=os.path.expanduser("~/datasets/pyg"))
    split_idx = dataset.get_idx_split()
    data = dataset[0]

    y = data.y.squeeze().to(device)
    train_idx = split_idx["train"].to(device)
    y_train = y[train_idx]

    if args.node2vec:
        data.x = torch.cat([data.x, torch.load('./models/products/embedding.pt')], dim=1)

    # Convert split indices to boolean masks and add them to `data`.
    for key, idx in split_idx.items():
        mask = torch.zeros(data.num_nodes, dtype=torch.bool)
        mask[idx] = True
        data[f'{key}_mask'] = mask

    cluster_data = ClusterData(data, num_parts=args.num_partitions,
                               recursive=False, save_dir=dataset.processed_dir)

    loader = ClusterLoader(cluster_data, batch_size=args.batch_size,
                           shuffle=True, num_workers=args.num_workers)

    subgraph_loader = NeighborSampler(data.edge_index, sizes=[-1],
                                      batch_size=1024, shuffle=False,
                                      num_workers=args.num_workers)

    model = Supernet(data.x.size(-1), args.hidden_channels, dataset.num_classes,
                 args.num_layers, args.dropout, arch=arch, track= not args.no_track).to(device)

    evaluator = Evaluator(name='ogbn-products')
    logger = Logger(args.runs, args)
    logger_ori = Logger(args.runs, args)
    logger.set_path(log_path)
    logger_ori.set_path(log_path.replace('.log', '-true.log'))
    
    # adj = process_adj(data)
    DAD = process_adj(data).to(device)

    for run in range(args.runs):
        model.reset_parameters()
        optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)

        best_val_acc = 0.

        for epoch in range(1, 1 + args.epochs):
            time_begin = time.time()
            loss, train_acc = train(model, loader, optimizer, device, arch)
            time_end = time.time()
            if epoch % args.log_steps == 0:
                log(f'Run: {run + 1:02d}, '
                      f'Epoch: {epoch:02d}, '
                      f'Loss: {loss:.4f}, '
                      f'Approx Train Acc: {train_acc:.4f} '
                      f'Time Approx: {time_end - time_begin:.4f} s'
                )

            if epoch >= args.begin_eval and epoch % args.eval_steps == 0:
                out, result = test(model, data, evaluator, subgraph_loader, device, arch)
                # logger.add_result(run, result)
                logger_ori.add_result(run, result)
                train_acc, valid_acc, test_acc = result
                log(f'Run: {run + 1:02d}, '
                      f'Epoch: {epoch:02d}, '
                      f'Train: {100 * train_acc:.2f}%, '
                      f'Valid: {100 * valid_acc:.2f}% '
                      f'Test: {100 * test_acc:.2f}%')
                
                if valid_acc > best_val_acc:
                    best_val_acc = valid_acc
                    y_soft = out.softmax(dim=-1).to(device)

        post = CorrectAndSmooth(num_correction_layers=100, correction_alpha=0.8,
                                num_smoothing_layers=100, smoothing_alpha=0.8,
                                autoscale=False, scale=10.)

        log('Correct and smooth...')
        # y_soft = post.correct(y_soft, y_train, train_idx, DAD)
        # y_soft = post.smooth(y_soft, y_train, train_idx, DA)
        y_soft = post.correct(y_soft, y_train, train_idx, DAD)
        y_soft = post.smooth(y_soft, y_train, train_idx, DAD)
        log('Done!')
        train_acc, val_acc, test_acc, _ = test_out(y_soft, data, split_idx, evaluator)
        log(f'Train: {train_acc:.4f}, Val: {val_acc:.4f}, Test: {test_acc:.4f}')

        result = (train_acc, val_acc, test_acc)
        logger.add_result(run, result)

        logger.print_statistics(run)
        logger_ori.print_statistics(run)
    logger.print_statistics()
    logger_ori.print_statistics()


if __name__ == "__main__":
    main()
