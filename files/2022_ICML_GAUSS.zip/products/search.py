import argparse
import torch
from tqdm import tqdm
import torch.nn.functional as F
from torch_geometric.loader import ClusterData, ClusterLoader
from .supernet import Supernet, PRODUCT_SIMPLE_BUFF
import os
from ogb.nodeproppred import PygNodePropPredDataset
from search import EvolutionAlgorithm
from functools import partial
from supernet.ops import uniform_sample, mutate
from itertools import product

@torch.no_grad()
def valid(model, loader, device, target, archs):
    model.train()

    total_examples = 0
    losses = [0] * len(archs)
    corrects = [0] * len(archs)
    procs = tqdm(total=len(archs) * len(loader))
    for data in loader:
        data = data.to(device)
        if data.valid_mask.sum() == 0:
            continue
        y = data.y.squeeze(1)[data.valid_mask]
        num_examples = data.valid_mask.sum().item()
        total_examples += num_examples
        for i, arch in enumerate(archs):
            out = model(data.x, data.edge_index, arch)[data.valid_mask]
            loss = F.nll_loss(out, y)
            losses[i] += loss.item() * num_examples
            corrects[i] += out.argmax(dim=-1).eq(y).sum().item()
            procs.update(1)
    
    if target == 'loss':
        return [l / total_examples for l in losses]
    else:
        return [-a / total_examples for a in corrects]

def main():
    parser = argparse.ArgumentParser(description='OGBN-Products (Cluster-GCN)')
    parser.add_argument('--device', type=int, default=0)
    parser.add_argument('--num_partitions', type=int, default=15000)
    parser.add_argument('--num_workers', type=int, default=12)
    parser.add_argument('--num_layers', type=int, default=3)
    parser.add_argument('--batch_size', type=int, default=32)
    parser.add_argument('--hidden_channels', type=int, default=256)
    parser.add_argument('--dropout', type=float, default=0.5)
    parser.add_argument('--search', type=int, nargs="+", default=[500, 5, 100])
    parser.add_argument('--model', type=str)
    parser.add_argument('--space', type=str, default='buff', choices=['buff', 'full'])
    parser.add_argument('--target', default='loss', type=str, choices=['loss', 'acc'])
    parser.add_argument('--log_path', type=str, default='./logs/products/search.log')
    parser.add_argument('--track', action='store_true')

    args = parser.parse_args()
    print(args)

    device = f'cuda:{args.device}' if torch.cuda.is_available() else 'cpu'
    device = torch.device(device)

    if args.space == 'buff':
        args.space = PRODUCT_SIMPLE_BUFF
    else:
        raise "Cannot support {}".format(args.space)

    dataset = PygNodePropPredDataset(name='ogbn-products', root=os.path.expanduser("~/datasets/pyg"))
    split_idx = dataset.get_idx_split()
    data = dataset[0]

    # Convert split indices to boolean masks and add them to `data`.
    for key, idx in split_idx.items():
        mask = torch.zeros(data.num_nodes, dtype=torch.bool)
        mask[idx] = True
        data[f'{key}_mask'] = mask

    cluster_data = ClusterData(data, num_parts=args.num_partitions,
                               recursive=False, save_dir=dataset.processed_dir)

    loader = ClusterLoader(cluster_data, batch_size=args.batch_size,
                           shuffle=True, num_workers=args.num_workers)

    model = Supernet(data.x.size(-1), args.hidden_channels, dataset.num_classes,
                 args.num_layers, args.dropout, space=args.space, track=args.track).to(device)
    
    model.load_state_dict(torch.load(args.model))
    
    # since the space is small, we can directly list all
    archs = [a for a in product(*[args.space for _ in range(args.num_layers + 1)])]
    
    '''
    result = EvolutionAlgorithm(
        partial(uniform_sample, args.num_layers, args.space),
        partial(mutate, space=args.space),
        partial(valid, model, loader, device, args.target),
        *args.search
    ).search()
    '''
    performance = valid(model, loader, device, args.target, archs)
    result = [(a, p) for a, p in zip(archs, performance)]
    result = sorted(result, key=lambda x:x[1])
    
    for r in result:
        print(r)
        open(args.log_path, 'a').write(str(r) + '\n')

if __name__ == "__main__":
    main()
