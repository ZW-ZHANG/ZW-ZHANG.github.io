import argparse

import torch
import torch.nn.functional as F

from torch_geometric.loader import ClusterData, ClusterLoader, NeighborSampler
from .supernet import Supernet
from torch_geometric.utils import to_undirected
from torch_sparse import SparseTensor

import os
import time

from ogb.nodeproppred import PygNodePropPredDataset, Evaluator

from utils import Logger
from arxiv_pyg.gcnii_layer import GCNIIdenseConv


class GCNIIdense_model(torch.nn.Module):
    def __init__(self, in_channels, hidden_channels, out_channels, num_layers,dropout,alpha,norm):
        super(GCNIIdense_model, self).__init__()
        self.convs = torch.nn.ModuleList()
        self.convs.append(torch.nn.Linear(in_channels, hidden_channels))
        for _ in range(num_layers):
            self.convs.append(GCNIIdenseConv(hidden_channels, hidden_channels,bias=norm, cached=False))
        self.convs.append(torch.nn.Linear(hidden_channels,out_channels))
        self.reg_params = list(self.convs[1:-1].parameters())
        self.non_reg_params = list(self.convs[0:1].parameters())+list(self.convs[-1:].parameters())
        self.dropout = dropout
        self.alpha = alpha

    def forward(self, x, edge_index, arch=None):
        _hidden = []
        x = F.dropout(x, self.dropout ,training=self.training)
        x = F.relu(self.convs[0](x))
        _hidden.append(x)
        for i,con in enumerate(self.convs[1:-1]):
            x = F.dropout(x, self.dropout ,training=self.training)
            x = F.relu(con(x, edge_index,self.alpha, _hidden[0], None))+_hidden[-1]
            _hidden.append(x)
        x = F.dropout(x, self.dropout ,training=self.training)
        x = self.convs[-1](x)
        return F.log_softmax(x, dim=1)


def train(model, loader, optimizer, device, arch):
    model.train()

    total_loss = total_examples = 0
    total_correct = total_examples = 0
    for data in loader:
        data = data.to(device)
        if data.train_mask.sum() == 0:
            continue
        optimizer.zero_grad()
        out = model(data.x, data.edge_index, arch)[data.train_mask]
        y = data.y.squeeze(1)[data.train_mask]
        loss = F.nll_loss(out, y)
        loss.backward()
        optimizer.step()

        num_examples = data.train_mask.sum().item()
        total_loss += loss.item() * num_examples
        total_examples += num_examples

        total_correct += out.argmax(dim=-1).eq(y).sum().item()

    return total_loss / total_examples, total_correct / total_examples


@torch.no_grad()
def test(model, data, evaluator, test_loader, device, arch):
    model.eval()

    total_loss = total_examples = 0
    total_correct = total_examples = 0
    train_label = []
    valid_label = []
    test_label = []
    train_pred = []
    valid_pred = []
    test_pred = []
    for data in test_loader:
        data = data.to(device)
        out = model(data.x, data.edge_index, arch)
        y = data.y.squeeze(1)

        if data.train_mask.sum() > 0:
            train_label.extend(y[data.train_mask].tolist())
            train_pred.extend(out[data.train_mask].tolist())
        if data.valid_mask.sum() > 0:
            valid_label.extend(y[data.valid_mask].tolist())
            valid_pred.extend(out[data.valid_mask].tolist())
        if data.test_mask.sum() > 0:
            test_label.extend(y[data.test_mask].tolist())
            test_pred.extend(out[data.test_mask].tolist())

    train_acc = evaluator.eval({
        'y_true': torch.tensor(train_label)[:, None],
        'y_pred': torch.tensor(train_pred).argmax(dim=1, keepdim=True)
    })['acc']
    valid_acc = evaluator.eval({
        'y_true': torch.tensor(valid_label)[:, None],
        'y_pred': torch.tensor(valid_pred).argmax(dim=1, keepdim=True)
    })['acc']
    test_acc = evaluator.eval({
        'y_true': torch.tensor(test_label)[:, None],
        'y_pred': torch.tensor(test_pred).argmax(dim=1, keepdim=True)
    })['acc']

    return out, (train_acc, valid_acc, test_acc)

def process_adj(data):
    N = data.num_nodes
    data.edge_index = to_undirected(data.edge_index, data.num_nodes)

    row, col = data.edge_index

    adj = SparseTensor(row=row, col=col, sparse_sizes=(N, N))
    adj = adj.set_diag()
    deg = adj.sum(dim=1).to(torch.float)
    deg_inv_sqrt = deg.pow(-0.5)
    deg_inv_sqrt[deg_inv_sqrt == float('inf')] = 0
    adj = deg_inv_sqrt.view(-1, 1) * adj * deg_inv_sqrt.view(1, -1)
    return adj

@torch.no_grad()
def test_out(out, data, split_idx, evaluator):

    y_pred = out.argmax(dim=-1, keepdim=True)

    train_acc = evaluator.eval({
        'y_true': data.y[split_idx['train']],
        'y_pred': y_pred[split_idx['train']],
    })['acc']
    valid_acc = evaluator.eval({
        'y_true': data.y[split_idx['valid']],
        'y_pred': y_pred[split_idx['valid']],
    })['acc']
    test_acc = evaluator.eval({
        'y_true': data.y[split_idx['test']],
        'y_pred': y_pred[split_idx['test']],
    })['acc']

    return train_acc, valid_acc, test_acc, out

def main():
    parser = argparse.ArgumentParser(description='OGBN-Products (Cluster-GCN)')
    parser.add_argument('--device', type=int, default=0)
    parser.add_argument('--log_steps', type=int, default=1)
    parser.add_argument('--num_partitions', type=int, default=15000)
    parser.add_argument('--num_workers', type=int, default=12)
    parser.add_argument('--num_layers', type=int, default=16)
    parser.add_argument('--hidden_channels', type=int, default=256)
    parser.add_argument('--dropout', type=float, default=0.5)
    parser.add_argument('--batch_size', type=int, default=32)
    parser.add_argument('--test-batch-size', type=int, default=128)
    parser.add_argument('--lr', type=float, default=0.001)
    parser.add_argument('--epochs', type=int, default=50)
    parser.add_argument('--eval_steps', type=int, default=5)
    parser.add_argument('--begin_eval', type=int, default=20)
    parser.add_argument('--runs', type=int, default=10)
    parser.add_argument('--no-track', action='store_true')
    parser.add_argument('--alpha', type=float, default=0.5, help='alpha_l')
    parser.add_argument('--norm', default='bn', help='norm layer.')

    args = parser.parse_args()
    
    log_path = os.path.join('./logs/products/retrain', f'gcn2-{args.num_layers}.log')
    os.makedirs('./logs/products/retrain', exist_ok=True)

    def log(strs):
        strs = str(strs)
        print(strs)
        open(log_path, 'a').write(strs + '\n')

    log(args)
    device = f'cuda:{args.device}' if torch.cuda.is_available() else 'cpu'
    device = torch.device(device)

    dataset = PygNodePropPredDataset(name='ogbn-products', root=os.path.expanduser("~/datasets/pyg"))
    split_idx = dataset.get_idx_split()
    data = dataset[0]

    y = data.y.squeeze().to(device)
    train_idx = split_idx["train"].to(device)
    y_train = y[train_idx]

    # Convert split indices to boolean masks and add them to `data`.
    for key, idx in split_idx.items():
        mask = torch.zeros(data.num_nodes, dtype=torch.bool)
        mask[idx] = True
        data[f'{key}_mask'] = mask

    cluster_data = ClusterData(data, num_parts=args.num_partitions,
                               recursive=False, save_dir=dataset.processed_dir)

    loader = ClusterLoader(cluster_data, batch_size=args.batch_size,
                           shuffle=True, num_workers=args.num_workers)

    loader_test = ClusterLoader(cluster_data, batch_size=args.batch_size, shuffle=False, num_workers=args.num_workers)

    evaluator = Evaluator(name='ogbn-products')
    logger_ori = Logger(args.runs, args)
    logger_ori.set_path(log_path)

    for run in range(args.runs):
        model = GCNIIdense_model(data.x.size(-1), args.hidden_channels,
                dataset.num_classes, args.num_layers,
                args.dropout, args.alpha, args.norm).to(device)

        optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)

        best_val_acc = 0.

        for epoch in range(1, 1 + args.epochs):
            time_begin = time.time()
            loss, train_acc = train(model, loader, optimizer, device, None)
            time_end = time.time()
            if epoch % args.log_steps == 0:
                log(f'Run: {run + 1:02d}, '
                      f'Epoch: {epoch:02d}, '
                      f'Loss: {loss:.4f}, '
                      f'Approx Train Acc: {train_acc:.4f} '
                      f'Time Approx: {time_end - time_begin:.4f} s'
                )

            if epoch >= args.begin_eval and epoch % args.eval_steps == 0:
                out, result = test(model, data, evaluator, loader_test, device, None)
                # logger.add_result(run, result)
                logger_ori.add_result(run, result)
                train_acc, valid_acc, test_acc = result
                log(f'Run: {run + 1:02d}, '
                      f'Epoch: {epoch:02d}, '
                      f'Train: {100 * train_acc:.2f}%, '
                      f'Valid: {100 * valid_acc:.2f}% '
                      f'Test: {100 * test_acc:.2f}%')

        logger_ori.print_statistics(run)
    logger_ori.print_statistics()


if __name__ == "__main__":
    main()
