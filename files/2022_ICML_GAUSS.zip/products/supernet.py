import torch
import torch.nn.functional as F
from supernet.ops import op
from supernet.conv import Conv
from tqdm import tqdm

PRODUCT_SIMPLE_BUFF = [
    # "gcn",
    "sage",
    "graph",
    "linear",
    "gin",
    "gatv2"
]

class Supernet(torch.nn.Module):
    def __init__(self, in_channels, hidden_channels, out_channels, num_layers,
                 dropout, space=PRODUCT_SIMPLE_BUFF, arch=None, bn=True, res=False, track=False):
        super().__init__()
        if arch is None: self.space = [space] * (num_layers + 1)
        else: self.space = [[x] for x in arch]
        self.inProj = torch.nn.Linear(in_channels, hidden_channels)
        self.use_bn = bn
        if self.use_bn:
            self.bn = torch.nn.BatchNorm1d(hidden_channels, track_running_stats=track)
        else:
            self.bn = torch.nn.Identity()
        self.convs = torch.nn.ModuleList()
        for i in range(num_layers):
            self.convs.append(Conv(self.space[i], hidden_channels, hidden_channels, pos=2, act=F.relu, dropout=dropout, bn=bn, res=res, track=track))
        self.convs.append(Conv(self.space[-1], hidden_channels, out_channels, pos=0, bn=bn, res=False, track=track))

        self.linear = torch.nn.Linear(hidden_channels, out_channels)
        self.weights = torch.nn.Parameter(torch.randn((len(self.convs))))
        self.dropout = dropout

    def reset_parameters(self):
        self.inProj.reset_parameters()
        self.linear.reset_parameters()
        if isinstance(self.bn, torch.nn.BatchNorm1d):
            self.bn.reset_parameters()
        torch.nn.init.normal_(self.weights)
        for conv in self.convs:
            conv.reset_parameters()

    def forward(self, x, edge_index, archs):
        assert len(archs) == len(self.convs), "arch lenth {} while conv lengh {}".format(len(archs), len(self.convs))
        x = self.inProj(x)
        inp = x
        x = self.bn(x)
        x = F.relu(x)
        for i, (conv, a) in enumerate(zip(self.convs, archs)):
            x = conv(x, edge_index, a)
            if i != len(self.convs) - 1:
                x = x + 0.2*inp
 
        return torch.log_softmax(x, dim=-1)

    def inference(self, x_all, subgraph_loader, device, archs):
        assert len(archs) == len(self.convs)
        pbar = tqdm(total=x_all.size(0) * len(self.convs))
        pbar.set_description('Evaluating')
        
        x_all = self.inProj(x_all.to(device))
        x_all = x_all.cpu()
        inp = x_all
        x_all = self.bn(x_all.to(device)).cpu()
        x_all = F.relu(x_all)
        out = []
        for i, (conv, a) in enumerate(zip(self.convs, archs)):
            xs = []
            for batch_size, n_id, adj in subgraph_loader:
                edge_index, _, size = adj.to(device)
                x = x_all[n_id].to(device)
                x_target = x[:size[1]]
                x = conv((x, x_target), edge_index, a)
                xs.append(x.cpu())

                pbar.update(batch_size)

            x_all = torch.cat(xs, dim=0)
            if i != len(self.convs) - 1:
                x_all = x_all + 0.2*inp
        pbar.close()

        return x_all
