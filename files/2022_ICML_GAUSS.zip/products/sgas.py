import torch
import torch_geometric.utils as pygutil
import torch_geometric.transforms as T
import os
from ogb.nodeproppred import PygNodePropPredDataset
from littleballoffur import PageRankBasedSampler
import torch
import torch.nn.functional as F
from supernet.conv import Conv
from baseline.sgas import SNAS, DARTS, SGAS
import torch_geometric.transforms as T
import os

def get_dataset(full=False, node_number=0.15):

    dataset = dataset = PygNodePropPredDataset(name='ogbn-products', root=os.path.expanduser("~/datasets/pyg"))
    num_classes = dataset.num_classes
    data = dataset[0]
    data.y = data.y[:,0]

    split_idx = dataset.get_idx_split()
    train_idx = split_idx['train']
    valid_idx = split_idx['valid']
    test_idx = split_idx['test']

    data.train_mask = torch.zeros(len(data.y)).bool()
    data.valid_mask = torch.zeros(len(data.y)).bool()
    data.test_mask = torch.zeros(len(data.y)).bool()

    data.train_mask[train_idx] = True
    data.valid_mask[valid_idx] = True
    data.test_mask[test_idx] = True

    if full:
        return data, num_classes
    
    network = pygutil.to_networkx(data, node_attrs=['x', 'train_mask', 'valid_mask', 'test_mask', 'y'], to_undirected=True, remove_self_loops=True)
    sampler = PageRankBasedSampler(int(network.number_of_nodes() * node_number))
    network_sampled = sampler.sample(network)
    data = pygutil.from_networkx(network_sampled)
    data.edge_index, _ = pygutil.add_self_loops(data.edge_index)
    data.edge_index = pygutil.to_undirected(data.edge_index)
    return data, num_classes


PRODUCT_SIMPLE_BUFF = [
    # "gcn",
    "sage",
    "graph",
    "linear",
    "gin",
    "gatv2"
]

class Supernet(torch.nn.Module):
    def __init__(self, in_channels, hidden_channels, out_channels, num_layers,
                 dropout, space=PRODUCT_SIMPLE_BUFF, arch=None, bn=True, res=False, track=False):
        super().__init__()
        if arch is None: self.space = [space] * num_layers
        else: self.space = [[x] for x in arch]
        self.inProj = torch.nn.Linear(in_channels, hidden_channels)
        self.use_bn = bn
        if self.use_bn:
            self.bn = torch.nn.BatchNorm1d(hidden_channels, track_running_stats=track)
        else:
            self.bn = torch.nn.Identity()
        self.convs = torch.nn.ModuleList()
        for i in range(num_layers - 1):
            self.convs.append(Conv(self.space[i], hidden_channels, hidden_channels, pos=2, act=F.relu, dropout=dropout, bn=bn, res=res, track=track))
        self.convs.append(Conv(self.space[-1], hidden_channels, out_channels, pos=0, bn=bn, res=False, track=track))

        self.linear = torch.nn.Linear(hidden_channels, out_channels)
        self.weights = torch.nn.Parameter(torch.randn((len(self.convs))))
        self.dropout = dropout

    def reset_parameters(self):
        self.inProj.reset_parameters()
        self.linear.reset_parameters()
        if isinstance(self.bn, torch.nn.BatchNorm1d):
            self.bn.reset_parameters()
        torch.nn.init.normal_(self.weights)
        for conv in self.convs:
            conv.reset_parameters()

    def forward(self, x, edge_index, edge_group):
        x = self.inProj(x)
        inp = x
        x = self.bn(x)
        x = F.relu(x)
        for i, conv in enumerate(self.convs):
            xs = [conv(x, edge_index, a) for a in self.space[i]]
            x = edge_group.forward(xs, i)
            if i != len(self.convs) - 1:
                x = x + 0.2*inp
 
        return torch.log_softmax(x, dim=-1)

def supernet_step(opt_supernet, supernet, edge_group, data):
    supernet.train()
    edge_group.eval()
    opt_supernet.zero_grad()
    out = supernet(data.x, data.edge_index, edge_group)[data.train_mask]
    loss = F.nll_loss(out, data.y[data.train_mask])
    loss.backward()
    opt_supernet.step()

def edge_step(opt_edge, supernet, edge_group, data):
    supernet.eval()
    edge_group.train()
    opt_edge.zero_grad()
    out = supernet(data.x, data.edge_index, edge_group)[data.valid_mask]
    loss = F.nll_loss(out, data.y[data.valid_mask])
    loss.backward()
    opt_edge.step()

def main():
    import argparse
    parser = argparse.ArgumentParser(description='sgas-products')
    parser.add_argument('--device', type=str, default="cuda")
    parser.add_argument('--num-layers', type=int, default=4)
    parser.add_argument('--n-hidden', type=int, default=256)

    parser.add_argument('--dropout', type=float, default=0.5)
    parser.add_argument('--lr', type=float, default=0.001)
    parser.add_argument('--edge-lr', type=float, default=3e-4)
    parser.add_argument('--epochs', type=int, default=50)
    parser.add_argument('--edge-epoch', type=int, default=5)
    parser.add_argument('--determine-epoch', type=int, default=51)
    parser.add_argument('--edge-type', type=str, choices=['darts', 'sgas', 'egan'], default='egan')
    parser.add_argument('--sample-ratio', type=float, default=1.0)
    args = parser.parse_args()
    print(args)

    device = args.device

    data, num_classes = get_dataset(args.sample_ratio == 1, args.sample_ratio)
    data = data.to(device)
    
    # supernet = Supernet(data.x.size(1), args.n_hidden, num_classes, args.num_layers, args.dropout, track=True).cuda()
    supernet = Supernet(data.x.size(-1), args.n_hidden, num_classes,
                    args.num_layers, args.dropout, track=False).cuda()

    edge_group = {'sgas': SGAS, 'darts': DARTS, 'egan': SNAS}[args.edge_type](len(PRODUCT_SIMPLE_BUFF), args.num_layers, -1).to(args.device)

    opt_supernet = torch.optim.Adam(supernet.parameters(), lr=args.lr)
    opt_edge = torch.optim.Adam(edge_group.parameters(), lr=args.edge_lr)

    for e in range(1, args.epochs + 1):
        supernet_step(opt_supernet, supernet, edge_group, data)

        if e % args.edge_epoch == 0:
            print('edge step at', e)
            edge_step(opt_edge, supernet, edge_group, data)
        
        if e % args.determine_epoch == 0:
            edge_group.determine()
            print('edge determine', e)
            print([edge_group.retrieve(i) for i in range(args.num_layers)])
            if len(edge_group.determined) == len(edge_group.params):
                break
    
    print([PRODUCT_SIMPLE_BUFF[edge_group.retrieve(i).argmax()] for i in range(args.num_layers)])

if __name__ == '__main__':
    main()
