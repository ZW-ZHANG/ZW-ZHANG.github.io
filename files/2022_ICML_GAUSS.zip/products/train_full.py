import argparse

import torch, random
import torch.nn.functional as F

import numpy as np

from torch_geometric.loader import ClusterData, ClusterLoader
from .supernet import Supernet
from sampler import RLSampler, RandomSampler

import os
import time
from functools import partial

from ogb.nodeproppred import PygNodePropPredDataset
from .supernet import PRODUCT_SIMPLE_BUFF
from tqdm import tqdm

def train_data(model, data, train_idx, optimizer, args, sampler, epoch, num_classes):
    model.train()
    optimizer.zero_grad()
    archs = sampler.samples(args.repeat)

    if args.use_curriculum:
        judgement = None
        best_acc = 0
        if epoch < args.warm_up:
            # min_ratio = args.min_ratio[0]
            min_ratio = epoch / args.epochs * (args.min_ratio[1] - args.min_ratio[0]) + args.min_ratio[0]
        else:
            min_ratio = epoch / args.epochs * (args.min_ratio[1] - args.min_ratio[0]) + args.min_ratio[0]
            # min_ratio = args.min_ratio[1]
            archs = sorted(archs, key=lambda x:x[1])
    
    loss_array = []

    y = data.y[train_idx].squeeze(1)
    for arch, score in archs:
        ratio = score if args.no_baseline else 1.
        out = model(data.x, data.edge_index, arch)[train_idx]

        if args.min_clip > 0:
            ratio = max(ratio, args.min_clip)
        if args.max_clip > 0:
            ratio = min(ratio, args.max_clip)

        loss = F.nll_loss(out, y, reduction="none") / args.repeat * ratio
        
        aggrement = (out.argmax(dim=1) == y)
        cur_acc = aggrement.float().mean()
        if args.use_curriculum and (judgement is None or cur_acc > best_acc):
            # cal the judgement
            judgement = torch.ones_like(loss).float()
            bar = 1 / num_classes
            wrong_idxs = (~aggrement).nonzero()[:, 0] # .squeeze()
            # pass by the bar
            distributions = torch.exp(out)
            try:
                wrong_idxs = wrong_idxs[distributions[wrong_idxs].max(dim=1)[0] > min(5 * bar, 0.7)]
            except:
                import pdb
                pdb.set_trace()
            sorted_idxs = distributions[wrong_idxs].max(dim=1)[0].sort(descending=True)[1][:int(args.max_ratio * out.size(0))]
            wrong_idxs = wrong_idxs[sorted_idxs]

            if min_ratio < 0:
                judgement = judgement.bool()
                judgement[wrong_idxs] = False
            else:
                judgement[wrong_idxs] = min_ratio

            loss = loss.mean()
            best_acc = cur_acc
        else:
            if not args.use_curriculum:
                loss = loss.mean()
            else:
                if min_ratio < 0: loss = loss[judgement].mean()
                else: loss = (loss * judgement).mean()


        loss.backward()
        loss_array.append(loss.item())
    optimizer.step()

    return np.mean(loss_array)

def train(model, loader, optimizer, device, args, sampler, epoch, num_classes):
    losses = []
    for data in loader:
        data = data.to(device)
        if data.train_mask.sum() == 0:
            continue
        loss = train_data(model, data, data.train_mask, optimizer, args, sampler, epoch, num_classes)
        losses.append(loss)

    return np.mean(losses)

@torch.no_grad()
def arch2score(archs, model, loader, gradient=False, device='cuda'):
    model.eval()
    losses = [0. for _ in archs]
    accs = [0. for _ in archs]
    idx = 0
    for data in tqdm(loader):
        data = data.to(device)
        if data.valid_mask.sum() == 0:
            continue
        idx += 1
        y = data.y.squeeze(1)[data.valid_mask]
        for i, a in enumerate(archs):
            out = model(data.x, data.edge_index, a)[data.valid_mask]
            losses[i] = losses[i] * (idx - 1) / idx + F.nll_loss(out, y).item() / idx
            accs[i] = accs[i] * (idx - 1) / idx + (out.argmax(1) == y).float().mean().item() / idx
    return losses, accs, None

def main():
    parser = argparse.ArgumentParser(description='OGBN-Products (Cluster-GCN)')
    parser.add_argument('--device', type=int, default=0)
    parser.add_argument('--log_steps', type=int, default=1)
    parser.add_argument('--num_partitions', type=int, default=15000)
    parser.add_argument('--num_workers', type=int, default=12)
    parser.add_argument('--num_layers', type=int, default=3)
    parser.add_argument('--hidden_channels', type=int, default=256)
    parser.add_argument('--dropout', type=float, default=0.5)
    parser.add_argument('--batch_size', type=int, default=32)
    parser.add_argument('--lr', type=float, default=0.001)
    parser.add_argument('--epochs', type=int, default=50)
    parser.add_argument('--track', action='store_true')

    parser.add_argument('--save-epoch', type=int, default=5)
    parser.add_argument('--repeat', type=int, default=10)

    # search
    parser.add_argument('--space', type=str, default='buff', choices=['buff', 'full'])

    # arch sampler
    parser.add_argument('--use-sampler', action='store_true')
    parser.add_argument("--sampler-fit", type=int, default=5)
    parser.add_argument("--T", type=float, default=1.0)
    parser.add_argument("--no-baseline", action="store_true", help="whether to force multiplying 1.")
    parser.add_argument("--restart", type=int, default=-1)
    parser.add_argument("--warm-up", type=float, default=0.4)
    parser.add_argument("--lr-sampler", type=float, default=1e-3)
    parser.add_argument("--epoch-sampler", type=int, default=5)
    parser.add_argument("--iter-sampler", type=int, default=7)
    parser.add_argument("--entropy", type=float, default=0.0)
    parser.add_argument("--max-clip", type=float, default=-1)
    parser.add_argument('--min-clip', type=float, default=-1)

    # curriculum
    parser.add_argument('--use-curriculum', action='store_true')
    parser.add_argument("--max-ratio", type=float, default=0.2)
    parser.add_argument("--min-ratio", type=float, nargs="+", default=[0.2, 1.0])
    parser.add_argument("--seed", type=int, default=0)

    args = parser.parse_args()
    print(args)

    # set seed
    torch.manual_seed(args.seed)
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True

    if args.space == 'buff':
        args.space = PRODUCT_SIMPLE_BUFF
    else:
        raise "Cannot support {}".format(args.space)

    os.makedirs(os.path.join("models", "products"), exist_ok=True)

    device = f'cuda:{args.device}' if torch.cuda.is_available() else 'cpu'
    device = torch.device(device)

    dataset = PygNodePropPredDataset(name='ogbn-products', root=os.path.expanduser("~/datasets/pyg"))
    split_idx = dataset.get_idx_split()
    data = dataset[0]

    # Convert split indices to boolean masks and add them to `data`.
    for key, idx in split_idx.items():
        mask = torch.zeros(data.num_nodes, dtype=torch.bool)
        mask[idx] = True
        data[f'{key}_mask'] = mask

    if args.use_sampler:
        sampler = RLSampler(args.space, args.num_layers + 1, epochs=args.epoch_sampler, iter=args.iter_sampler, lr=args.lr_sampler, T=args.T, entropy=args.entropy)
    else:
        sampler = RandomSampler(args.space, args.num_layers + 1)

    args.warm_up = int(args.warm_up * args.epochs)

    folder_name = f'logs/products/repeat-{args.repeat}-ais-{args.use_sampler}-gpl-{args.use_curriculum}'

    os.makedirs(folder_name, exist_ok=True)
    os.makedirs(os.path.join(folder_name, "models"), exist_ok=True)
    os.makedirs(os.path.join(folder_name, "sampler"), exist_ok=True)

    def log(strs):
        print(strs)
        open(os.path.join(folder_name, "train.log"), "a").write(strs + '\n')

    cluster_data = ClusterData(data, num_parts=args.num_partitions,
                               recursive=False, save_dir=dataset.processed_dir)

    loader = ClusterLoader(cluster_data, batch_size=args.batch_size,
                           shuffle=True, num_workers=args.num_workers)

    model = Supernet(data.x.size(-1), args.hidden_channels, dataset.num_classes,
                 args.num_layers, args.dropout, space=args.space, track=args.track).to(device)
    
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)

    sampler_fit_time = -1
    evaled_epoch = -1

    for epoch in range(1, 1 + args.epochs):
        time_begin = time.time()
        # model: Any, loader: Any, optimizer: Any, device: Any, args: Any, sampler: Any, epoch: Any, num_classes: Any
        loss = train(model, loader, optimizer, device, args, sampler, epoch, dataset.num_classes)
        time_end = time.time()
        if epoch % args.log_steps == 0:
            print(
                f'Epoch: {epoch:02d}, '
                f'Loss: {loss:.4f}, '
                f'Time Approx: {time_end - time_begin:.4f} s'
            )

        if args.use_sampler and epoch % args.sampler_fit == 0 and epoch >= args.warm_up and epoch < args.epochs:
            # log(f"Epoch: {epoch:02d}, fitting the sampler...")
            # if args.restart: sampler.restart()
            sampler_fit_time += 1
            if args.restart > 0 and sampler_fit_time % args.restart == 0:
                log('\nrestart\n')
                sampler.restart()
            sampler.fit(partial(arch2score, model=model, loader=loader, device=device))
            sampler.log(print)
            sampler.save(os.path.join(folder_name, "sampler"), epoch)

        if epoch % args.save_epoch == 0:
            torch.save(model.state_dict(), os.path.join(folder_name, "models", f"{epoch}.pt"))
            torch.save(optimizer.state_dict(), os.path.join(folder_name, "models", f"{epoch}.opt"))

    # save to files
    torch.save(model.state_dict(), os.path.join("models", "products", f"{args.repeat}-{args.epochs}.pt"))

if __name__ == "__main__":
    main()
