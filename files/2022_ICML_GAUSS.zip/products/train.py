import argparse

import torch
import torch.nn.functional as F

from torch_geometric.loader import ClusterData, ClusterLoader
from .supernet import Supernet
from supernet.ops import uniform_sample

import os
import time

from ogb.nodeproppred import PygNodePropPredDataset
from .supernet import PRODUCT_SIMPLE_BUFF

def train(model, loader, optimizer, device, args):
    model.train()

    total_loss = total_examples = 0
    total_correct = total_examples = 0
    for data in loader:
        data = data.to(device)
        if data.train_mask.sum() == 0:
            continue
        optimizer.zero_grad()
        archs = [uniform_sample(args.num_layers + 1, args.space) for _ in range(args.repeat)]
        num_examples = data.train_mask.sum().item()
        for arch in archs:
            out = model(data.x, data.edge_index, arch)[data.train_mask]
            y = data.y.squeeze(1)[data.train_mask]
            loss = F.nll_loss(out, y) / args.repeat
            loss.backward()
            total_loss += loss.item() * num_examples
            total_examples += num_examples
            total_correct += out.argmax(dim=-1).eq(y).sum().item()
        optimizer.step()

    return total_loss / total_examples, total_correct / total_examples

def main():
    parser = argparse.ArgumentParser(description='OGBN-Products (Cluster-GCN)')
    parser.add_argument('--device', type=int, default=0)
    parser.add_argument('--log_steps', type=int, default=1)
    parser.add_argument('--num_partitions', type=int, default=15000)
    parser.add_argument('--num_workers', type=int, default=12)
    parser.add_argument('--num_layers', type=int, default=3)
    parser.add_argument('--hidden_channels', type=int, default=256)
    parser.add_argument('--dropout', type=float, default=0.5)
    parser.add_argument('--batch_size', type=int, default=32)
    parser.add_argument('--lr', type=float, default=0.001)
    parser.add_argument('--epochs', type=int, default=50)
    parser.add_argument('--track', action='store_true')

    # search
    parser.add_argument('--repeat', type=int, default=5)
    parser.add_argument('--space', type=str, default='buff', choices=['buff', 'full'])


    args = parser.parse_args()
    print(args)

    if args.space == 'buff':
        args.space = PRODUCT_SIMPLE_BUFF
    else:
        raise "Cannot support {}".format(args.space)

    os.makedirs(os.path.join("models", "products"), exist_ok=True)

    device = f'cuda:{args.device}' if torch.cuda.is_available() else 'cpu'
    device = torch.device(device)

    dataset = PygNodePropPredDataset(name='ogbn-products', root=os.path.expanduser("~/datasets/pyg"))
    split_idx = dataset.get_idx_split()
    data = dataset[0]

    # Convert split indices to boolean masks and add them to `data`.
    for key, idx in split_idx.items():
        mask = torch.zeros(data.num_nodes, dtype=torch.bool)
        mask[idx] = True
        data[f'{key}_mask'] = mask

    cluster_data = ClusterData(data, num_parts=args.num_partitions,
                               recursive=False, save_dir=dataset.processed_dir)

    loader = ClusterLoader(cluster_data, batch_size=args.batch_size,
                           shuffle=True, num_workers=args.num_workers)

    model = Supernet(data.x.size(-1), args.hidden_channels, dataset.num_classes,
                 args.num_layers, args.dropout, space=args.space, track=args.track).to(device)
    
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
    for epoch in range(1, 1 + args.epochs):
        time_begin = time.time()
        loss, train_acc = train(model, loader, optimizer, device, args)
        time_end = time.time()
        if epoch % args.log_steps == 0:
            print(
                f'Epoch: {epoch:02d}, '
                f'Loss: {loss:.4f}, '
                f'Approx Train Acc: {train_acc:.4f} '
                f'Time Approx: {time_end - time_begin:.4f} s'
            )

    # save to files
    torch.save(model.state_dict(), os.path.join("models", "products", f"{args.repeat}-{args.epochs}.pt"))

if __name__ == "__main__":
    main()
