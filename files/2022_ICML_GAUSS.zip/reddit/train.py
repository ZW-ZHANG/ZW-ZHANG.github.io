import argparse
import os
import torch
import torch.nn.functional as F
import torch_geometric.transforms as T
from sampler import RLSampler, RandomSampler
from utils import read_all_cs
from coauthor.supernet import COAUTHOR, Supernet
from .data import load_reddit
import random
from scipy.stats import kendalltau
from functools import partial
from tqdm import tqdm
import time

def train(model, data, train_idx, optimizer, args, sampler, epoch, num_classes):
    model.train()
    optimizer.zero_grad()
    archs = sampler.samples(args.repeat)

    if args.use_curriculum:
        judgement = None
        best_acc = 0
        if epoch < args.warm_up:
            # min_ratio = args.min_ratio[0]
            min_ratio = epoch / args.epochs * (args.min_ratio[1] - args.min_ratio[0]) + args.min_ratio[0]
        else:
            min_ratio = epoch / args.epochs * (args.min_ratio[1] - args.min_ratio[0]) + args.min_ratio[0]
            # min_ratio = args.min_ratio[1]
            archs = sorted(archs, key=lambda x:x[1])
    
    for arch, score in archs:
        ratio = score if args.no_baseline else 1.
        out = model(data, arch)[train_idx]

        if args.min_clip > 0:
            ratio = max(ratio, args.min_clip)
        if args.max_clip > 0:
            ratio = min(ratio, args.max_clip)

        loss = F.nll_loss(out, data.y[train_idx], reduction="none") / args.repeat * ratio
        
        aggrement = (out.argmax(dim=1) == data.y[train_idx])
        cur_acc = aggrement.float().mean()
        if args.use_curriculum and (judgement is None or cur_acc > best_acc):
            # cal the judgement
            judgement = torch.ones_like(loss).float()
            bar = 1 / num_classes
            wrong_idxs = (~aggrement).nonzero()[:, 0] # .squeeze()
            # pass by the bar
            distributions = torch.exp(out)
            try:
                wrong_idxs = wrong_idxs[distributions[wrong_idxs].max(dim=1)[0] > min(5 * bar, 0.7)]
            except:
                import pdb
                pdb.set_trace()
            sorted_idxs = distributions[wrong_idxs].max(dim=1)[0].sort(descending=True)[1][:int(args.max_ratio * out.size(0))]
            wrong_idxs = wrong_idxs[sorted_idxs]

            if min_ratio < 0:
                judgement = judgement.bool()
                judgement[wrong_idxs] = False
            else:
                judgement[wrong_idxs] = min_ratio

            loss = loss.mean()
            best_acc = cur_acc
        else:
            if not args.use_curriculum:
                loss = loss.mean()
            else:
                if min_ratio < 0: loss = loss[judgement].mean()
                else: loss = (loss * judgement).mean()


        loss.backward()
    optimizer.step()

    return loss.item()

@torch.no_grad()
def arch2score(archs, model, data, valid_idx, gradient=False):
    model.eval()
    losses = []
    accs = []
    for a in archs:
        out = model(data, a)[valid_idx]
        losses.append(F.nll_loss(out, data.y[valid_idx]).item())
        accs.append((out.argmax(1) == data.y[valid_idx]).float().mean().item())
    return losses, accs, None
        
def main():
    parser = argparse.ArgumentParser(description='gen_models')
    parser.add_argument('--device', type=int, default=0)
    parser.add_argument('--log_steps', type=int, default=1)
    parser.add_argument('--num_layers', type=int, default=2)
    parser.add_argument('--hidden_channels', type=int, default=256)

    parser.add_argument('--dropout', type=float, default=0.5)
    parser.add_argument('--lr', type=float, default=0.005)
    parser.add_argument('--epochs', type=int, default=50)
    parser.add_argument('--eval-epoch', type=int, default=-1)
    parser.add_argument('--save-epoch', type=int, default=5)
    parser.add_argument('--wd', type=float, default=0.0)
    parser.add_argument('--repeat', type=int, default=10)
    parser.add_argument('--track', action='store_true')
    parser.add_argument('--space', type=str, default='simple', choices=['simple', 'full'])
    parser.add_argument('--name', type=str, default='search')
    parser.add_argument('--restore-epoch', type=int, default=-1)
    parser.add_argument('--restore-folder', type=str)

    # arch sampler
    parser.add_argument('--use-sampler', action='store_true')
    parser.add_argument("--sampler-fit", type=int, default=5)
    parser.add_argument("--T", type=float, default=1.0)
    parser.add_argument("--no-baseline", action="store_true", help="whether to force multiplying 1.")
    parser.add_argument("--restart", type=int, default=-1)
    parser.add_argument("--warm-up", type=float, default=0.4)
    parser.add_argument("--lr-sampler", type=float, default=1e-3)
    parser.add_argument("--epoch-sampler", type=int, default=5)
    parser.add_argument("--iter-sampler", type=int, default=7)
    parser.add_argument("--entropy", type=float, default=0.0)
    parser.add_argument("--max-clip", type=float, default=-1)
    parser.add_argument('--min-clip', type=float, default=-1)

    # curriculum
    parser.add_argument('--use-curriculum', action='store_true')
    parser.add_argument("--max-ratio", type=float, default=0.2)
    parser.add_argument("--min-ratio", type=float, nargs="+", default=[0.2, 1.0])

    args = parser.parse_args()

    print(args)

    folder_name = f'logs/reddit/{args.name}-repeat-{args.repeat}-ais-{args.use_sampler}-gpl-{args.use_curriculum}'

    os.makedirs(folder_name)
    os.makedirs(os.path.join(folder_name, "models"))
    os.makedirs(os.path.join(folder_name, "sampler"))

    if args.eval_epoch > 0:
        arch_all = read_all_cs(f"logs/reddit/baseline")
        archs_gt = list(map(lambda x:x[0], arch_all))
        vals_gt = list(map(lambda x:x[1], arch_all))
        tests_gt = list(map(lambda x:x[2], arch_all))

    if args.use_sampler:
        sampler = RLSampler(COAUTHOR, args.num_layers, epochs=args.epoch_sampler, iter=args.iter_sampler, lr=args.lr_sampler, T=args.T, entropy=args.entropy)
    else:
        sampler = RandomSampler(COAUTHOR, args.num_layers)

    args.warm_up = int(args.warm_up * args.epochs)

    def log(strs):
        print(strs)
        open(os.path.join(folder_name, "train.log"), "a").write(strs + '\n')


    device = f'cuda:{args.device}' if torch.cuda.is_available() else 'cpu'
    device = torch.device(device)

    dataset, data, train_idx, valid_idx, test_idx, split_idx = load_reddit()

    model = Supernet(args.num_layers, data.x.size(-1), dataset.num_classes, args.hidden_channels, args.dropout, track=args.track, add_pre=True).cuda()
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=args.wd)

    sampler_fit_time = -1
    evaled_epoch = -1

    if args.restore_epoch > 0:
        model.load_state_dict(torch.load(os.path.join(args.restore_folder, f"{args.restore_epoch}.pt")))
        optimizer.load_state_dict(torch.load(os.path.join(args.restore_folder, f"{args.restore_epoch}.opt")))
        
        epoch = args.restore_epoch
        if args.use_sampler and epoch % args.sampler_fit == 0 and epoch >= args.warm_up and epoch < args.epochs:
            # log(f"Epoch: {epoch:02d}, fitting the sampler...")
            # if args.restart: sampler.restart()
            sampler_fit_time += 1
            if args.restart > 0 and sampler_fit_time % args.restart == 0:
                log('\nrestart\n')
                sampler.restart()
            sampler.fit(partial(arch2score, data=data, model=model, valid_idx=valid_idx))
            sampler.log(print)
            sampler.save(os.path.join(folder_name, "sampler"), epoch)
            if args.eval_epoch > 0:
                scores = sampler.evaluate(archs_gt)
            
            if evaled_epoch != epoch and args.eval_epoch > 0:
                losses, accs, _ = arch2score(archs_gt, model, data, valid_idx)
                log(
                    '*************** '
                    f'Epoch: {epoch:02d}, val tau: {- kendalltau(losses, vals_gt)[0]:.4f} {kendalltau(accs, vals_gt)[0]:.4f} '
                    f'test tau: {- kendalltau(losses, tests_gt)[0]:.4f} {kendalltau(accs, tests_gt)[0]:.4f} '
                    '***************'
                )
                evaled_epoch = epoch
            
            if args.eval_epoch > 0:
                log(f'Sampler Epoch: {epoch:02d}, {kendalltau(scores, vals_gt)[0]:.4f} {kendalltau(scores, tests_gt)[0]:.4f} {kendalltau(scores, accs)[0]:.4f}')


    for epoch in tqdm(range(max(1, 1 + args.restore_epoch), args.epochs + 1)):
        train(model, data, train_idx, optimizer, args, sampler, epoch, dataset.num_classes)

        if args.eval_epoch > 0 and epoch % args.eval_epoch == 0:
            # evaluate the current models
            evaled_epoch = epoch
            losses, accs, _ = arch2score(archs_gt, model, data, valid_idx)
            log(
                '*************** '
                f'Epoch: {epoch:02d}, val tau: {- kendalltau(losses, vals_gt)[0]:.4f} {kendalltau(accs, vals_gt)[0]:.4f} '
                f'test tau: {- kendalltau(losses, tests_gt)[0]:.4f} {kendalltau(accs, tests_gt)[0]:.4f} '
                '***************'
            )

        if args.use_sampler and epoch % args.sampler_fit == 0 and epoch >= args.warm_up and epoch < args.epochs:
            # log(f"Epoch: {epoch:02d}, fitting the sampler...")
            # if args.restart: sampler.restart()
            sampler_fit_time += 1
            if args.restart > 0 and sampler_fit_time % args.restart == 0:
                log('\nrestart\n')
                sampler.restart()
            sampler.fit(partial(arch2score, data=data, model=model, valid_idx=valid_idx))
            sampler.log(print)
            sampler.save(os.path.join(folder_name, "sampler"), epoch)
            if args.eval_epoch > 0:
                scores = sampler.evaluate(archs_gt)
            
            if evaled_epoch != epoch and args.eval_epoch > 0:
                losses, accs, _ = arch2score(archs_gt, model, data, valid_idx)
                log(
                    '*************** '
                    f'Epoch: {epoch:02d}, val tau: {- kendalltau(losses, vals_gt)[0]:.4f} {kendalltau(accs, vals_gt)[0]:.4f} '
                    f'test tau: {- kendalltau(losses, tests_gt)[0]:.4f} {kendalltau(accs, tests_gt)[0]:.4f} '
                    '***************'
                )
                evaled_epoch = epoch
            
            if args.eval_epoch > 0:
                log(f'Sampler Epoch: {epoch:02d}, {kendalltau(scores, vals_gt)[0]:.4f} {kendalltau(scores, tests_gt)[0]:.4f} {kendalltau(scores, accs)[0]:.4f}')

        if epoch % args.save_epoch == 0:
            torch.save(model.state_dict(), os.path.join(folder_name, "models", f"{epoch}.pt"))
            torch.save(optimizer.state_dict(), os.path.join(folder_name, "models", f"{epoch}.opt"))

if __name__ == "__main__":
    begin_time = time.time()
    main()
    end_time = time.time()
    print('Train graph supernet time cost', - begin_time + end_time, 's')
