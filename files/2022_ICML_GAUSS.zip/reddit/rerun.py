import argparse
import os
import torch
import torch.nn.functional as F
import torch_geometric.transforms as T
from utils import Logger
from coauthor.supernet import Supernet
import pickle
from .data import load_reddit

def train(model, data, train_idx, optimizer, arch):
    model.train()

    optimizer.zero_grad()
    out = model(data.x, data.adj_t, arch)[train_idx]
    loss = F.nll_loss(out, data.y.squeeze(1)[train_idx])
    loss.backward()
    optimizer.step()

    return loss.item()


def acc(pred, label):
    return (pred.argmax(dim=1) == label).float().mean().item()

@torch.no_grad()
def test(model, data, split_idx, arch):
    model.eval()

    out = model(data, arch)

    return [acc(out[split_idx[key]], data.y[split_idx[key]]) for key in ['train', 'valid', 'test']]

    
        
            
def main():
    parser = argparse.ArgumentParser(description='gen_models')
    parser.add_argument('--device', type=int, default=0)
    parser.add_argument('--log_steps', type=int, default=1)
    parser.add_argument('--num_layers', type=int, default=4)
    parser.add_argument('--hidden_channels', type=int, default=256)

    parser.add_argument('--dropout', type=float, default=0.5)
    parser.add_argument('--lr', type=float, default=0.005)
    parser.add_argument('--epochs', type=int, default=100)
    parser.add_argument('--wd', type=float, default=0.0)
    parser.add_argument('--runs', type=int, default=10)
    parser.add_argument('--no-track', action='store_true')
    parser.add_argument('--archs', type=str, default=str(['gcn'] * 4))
    parser.add_argument('--arch-path', type=str, default='./models/coauthor/archs.pkl')

    args = parser.parse_args()

    args.arch = eval(args.archs)
    if isinstance(args.arch, int):
        args.arch = pickle.load(open(args.arch_path, 'rb'))[args.arch]
    print(args)

    device = f'cuda:{args.device}' if torch.cuda.is_available() else 'cpu'
    device = torch.device(device)

    dataset, data, train_idx, valid_idx, test_idx, split_idx = load_reddit()

    model = Supernet(args.num_layers, data.x.size(-1), dataset.num_classes, args.hidden_channels, args.dropout, arch=args.arch, track=not args.no_track, add_pre=True).cuda()

    logger = Logger(args.runs, args)

    idxs = torch.cat([train_idx])
    for run in range(args.runs):
        print(sum(p.numel() for p in model.parameters()))
        
        model.reset_parameters()
        optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=args.wd)

        for epoch in range(1, args.epochs):
            model.train()
            optimizer.zero_grad()
            out = model(data, args.arch)[idxs]
            loss = F.nll_loss(out, data.y[idxs])
            loss.backward()
            optimizer.step()
            
            result = test(model, data, split_idx, args.arch)
            train_acc, valid_acc, test_acc = result
        
            print(f'Run: {run + 1:02d}, '
                      f'Epoch: {epoch:02d}, '
                      f'Loss: {loss:.4f}, '
                      f'Train: {100 * train_acc:.2f}%, '
                      f'Valid: {100 * valid_acc:.2f}% '
                      f'Test: {100 * test_acc:.2f}%')
            logger.add_result(run, result)
        logger.print_statistics(run)

    logger.print_statistics()

if __name__ == "__main__":
    main()
