import torch.nn as nn
import torch.nn.functional as F
from supernet.conv import Conv
from supernet.ops import op_dgl

PROTEINS = [
    'gat',
    'gcn',
    'sage',
    'gin',
    'cf',
    'linear'
]

class Supernet(nn.Module):
    def __init__(
        self,
        node_feats,
        edge_feats,
        n_classes,
        n_layers,
        n_heads,
        n_hidden,
        edge_emb,
        activation,
        dropout,
        input_drop,
        attn_drop,
        edge_drop,
        use_attn_dst=True,
        allow_zero_in_degree=False,
        space=PROTEINS,
        arch=None,
        track=False
    ):
        super().__init__()
        self.n_layers = n_layers
        self.n_heads = n_heads
        self.n_hidden = n_hidden
        self.n_classes = n_classes
        if arch is None:
            self.space = [space] * n_layers
        else:
            self.space = [[a] for a in arch]

        self.convs = nn.ModuleList()
        self.norms = nn.ModuleList()

        self.node_encoder = nn.Linear(node_feats, n_hidden)
        if edge_emb > 0:
            self.edge_encoder = nn.ModuleList()

        for i in range(n_layers):
            in_hidden = n_heads * n_hidden if i > 0 else n_hidden
            # in_hidden = n_hidden
            out_hidden = n_hidden

            if edge_emb > 0:
                self.edge_encoder.append(nn.Linear(edge_feats, edge_emb))
            self.convs.append(
                nn.ModuleDict({
                    name: op_dgl(
                        name, in_hidden, out_hidden * n_heads, 
                        edge_feat=edge_emb,
                        n_heads=n_heads,
                        attn_drop=attn_drop,
                        edge_drop=edge_drop,
                        use_attn_dst=use_attn_dst,
                        allow_zero_in_degree=allow_zero_in_degree,
                        use_symmetric_norm=False
                    ) for name in self.space[i]
                })
            )

            self.norms.append(nn.ModuleDict({name: nn.BatchNorm1d(
                out_hidden * n_heads, 
                track_running_stats=track) for name in self.space[i]}))

        self.pred_linear = nn.Linear(n_heads * n_hidden, n_classes)
        self.input_drop = nn.Dropout(input_drop)
        self.dropout = nn.Dropout(dropout)
        self.activation = activation

    def forward(self, g, arch):
        assert len(arch) == len(self.convs)
        if not isinstance(g, list):
            subgraphs = [g] * self.n_layers
        else:
            subgraphs = g

        h = subgraphs[0].srcdata["feat"]
        h = self.node_encoder(h)
        h = F.relu(h, inplace=True)
        h = self.input_drop(h)

        h_last = None

        for i, a in zip(range(self.n_layers), arch):
            if self.edge_encoder is not None:
                efeat = subgraphs[i].edata["feat"]
                efeat_emb = self.edge_encoder[i](efeat)
                efeat_emb = F.relu(efeat_emb, inplace=True)
            else:
                efeat_emb = None

            h = self.convs[i][a](subgraphs[i], h, efeat_emb)

            if h_last is not None:
                h += h_last[: h.shape[0], :]

            h_last = h

            h = self.norms[i][a](h)
            h = self.activation(h, inplace=True)
            h = self.dropout(h)

        h = self.pred_linear(h)

        return h
