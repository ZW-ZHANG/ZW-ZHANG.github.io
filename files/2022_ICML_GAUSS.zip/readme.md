# GAUSS: Graph ArchitectUre Search at Scale

Authors: [Chaoyu Guan](https://www.github.com/Frozenmad), Xin Wang, Hong Chen, Ziwei Zhang, Wenwu Zhu  
Paper can be found in here(coming soon).

## Abstract
Graph Neural Architecture Search (GNAS) has become a powerful method in automatically discovering suitable Graph Neural Network (GNN) architectures for different tasks. However, existing approaches fail to handle large-scale graphs because current performance estimation strategies in GNAS are computationally expensive for large-scale graphs and suffer from consistency collapse issues. To tackle these problems, we propose the **G**raph **A**rchitect**U**re **S**earch at **S**cale (GAUSS) method that can handle large-scale graphs by designing an efficient light-weight supernet and the joint architecture-graph sampling. In particular, a graph sampling-based single-path one-shot supernet is proposed to reduce the computation burden. To address the consistency collapse issues, we further explicitly consider the joint architecture-graph sampling through a novel architecture peer learning mechanism on the sampled sub-graphs and an architecture importance sampling algorithm. Our proposed framework is able to smooth the highly non-convex optimization objective and stabilize the architecture sampling process. We provide theoretical analyses on GAUSS and empirically evaluate it on five datasets whose vertex sizes range from $10^4$ to $10^8$. The experimental results demonstrate substantial improvements of GAUSS over other GNAS baselines on all datasets. To the best of our knowledge, the proposed GAUSS method is the first graph neural architecture search framework that can handle graphs with billions of edges within 1 GPU day.

> __TL;DR__: __GAUSS__ is a graph neural architecture search algorithm that can search for powerful GNN architectures on large-scale graphs (with up to $10^8$ nodes and $10^9$ edges) in __1 GPU day on NVIDIA V100 (32GB)__.

![Workflow of GAUSS](resources/workflow.svg)

## Requirements

```
Package                       Version
----------------------------- -----------
dgl                           0.8.0.post2
ogb                           1.3.3
torch                         1.10.0
torch-cluster                 1.6.0
torch-geometric               2.0.4
torch-scatter                 2.0.9
torch-sparse                  0.6.13
torch-spline-conv             1.2.1
```

## Usage

