""""""
import math
import torch
import torch.nn.functional as F

class DARTS(torch.nn.Module):
    def __init__(self, n_ops, n_layers, zeroid):
        super().__init__()
        self.n_ops = n_ops
        size_op = n_ops if zeroid < 0 else (n_ops + 1)
        self.params = torch.nn.ParameterDict({
            str(i): torch.nn.Parameter(torch.zeros(size_op), requires_grad=True) for i in range(n_layers)
        })
        self.zeroid = zeroid
        self.idxs_valid = [i for i in range(size_op) if i!= zeroid]
        self.determined = dict()
        self.size_op = size_op

    def determine(self):
        # select argmax for all parameters
        for key in self.params:
            prob = self.params[key].softmax(dim=0)
            if self.zeroid >= 0:
                prob[self.zeroid] = 0.
            self.determined[key] = torch.eye(len(prob))[prob.argmax(dim=0)].to(prob)
    
    def retrieve(self, key):
        key = str(key)
        if key in self.determined: return self.determined[key]
        return self.params[key].softmax(dim=0)

    def forward(self, features: list, key):
        assert len(features) == self.n_ops
        if self.zeroid >= 0:
            features.insert(self.zeroid, torch.zeros_like(features[0]))
        return sum([feature * w for feature, w in zip(features, self.retrieve(key))])


class SNAS(DARTS):
    def retrieve(self, key):
        key = str(key)
        if key in self.determined: return self.determined[key]
        return F.gumbel_softmax(self.params[key], dim=0)


class SGAS(DARTS):
    def __init__(self, n_ops, n_layers, zeroid):
        if zeroid == -1:
            # force add zero op
            super().__init__(n_ops, n_layers, n_ops)
        else:
            super().__init__(n_ops, n_layers, zeroid)

    def edge_importance(self):
        elements = []
        for key in self.params:
            if key not in self.determined:
                softmaxed = self.params[key].softmax(dim=0)
                elements.append([key, (1 - softmaxed[self.zeroid]).item()])
        return elements

    def selection_certainty(self):
        elements = []
        for key in self.params:
            if key not in self.determined:
                selected = self.params[key][self.idxs_valid]
                prob = selected.softmax(dim=0)
                log_prob = selected.log_softmax(dim=0)
                sc = 1 + (prob * log_prob).sum() / (math.log(len(prob)))
                elements.append([key, sc.item()])
        return elements

    def determine(self):
        # a determine step
        ei, sc = self.edge_importance(), self.selection_certainty()
        # print(ei, sc)
        # normalize ei and sc
        keys = [e[0] for e in ei]
        ei_score = self.normalize([e[1] for e in ei])
        sc_score = self.normalize([e[1] for e in sc])
        s1 = [[e1 * e2, key] for e1, e2, key in zip(ei_score, sc_score, keys)]
        s1 = sorted(s1, key=lambda x:x[0], reverse=True)
        edge_target = s1[0][1]
        param = self.params[edge_target].detach()
        # avoid zero
        param[self.zeroid] = 0.
        idxs = param.argmax()
        self.determined[edge_target] = torch.eye(len(param))[idxs].float().to(param.device)


    def normalize(self, elements):
        mins = min(elements)
        maxs = max(elements)
        if maxs - mins < 1e-4: return [0 for _ in range(len(elements))]
        return [(l - mins) / (maxs - mins) for l in elements]


class EdgeGroup(torch.nn.Module):
    def __init__(self, n_ops, n_layers, zeroid) -> None:
        super().__init__()
        self.params = torch.nn.ParameterDict({
            str(i): torch.nn.Parameter(torch.zeros(n_ops), requires_grad=True) for i in range(n_layers)
        })
        self.zeroid = zeroid
        self.n_ops = n_ops
        self.n_layers = n_layers
        self.idxs_valid = [i for i in range(n_ops) if i != zeroid]
        self.determined = dict()

    def edge_importance(self):
        elements = []
        for key in self.params:
            if key not in self.determined:
                softmaxed = self.params[key].softmax(dim=0)
                elements.append([key, (1 - softmaxed[self.zeroid]).item()])
        return elements

    def selection_certainty(self):
        elements = []
        for key in self.params:
            if key not in self.determined:
                selected = self.params[key][self.idxs_valid]
                prob = selected.softmax(dim=0)
                log_prob = selected.log_softmax(dim=0)
                sc = 1 + (prob * log_prob).sum() / (math.log(len(prob)))
                elements.append([key, sc.item()])
        return elements

    def determine(self):
        # a determine step
        ei, sc = self.edge_importance(), self.selection_certainty()
        # print(ei, sc)
        # normalize ei and sc
        keys = [e[0] for e in ei]
        ei_score = self.normalize([e[1] for e in ei])
        sc_score = self.normalize([e[1] for e in sc])
        s1 = [[e1 * e2, key] for e1, e2, key in zip(ei_score, sc_score, keys)]
        s1 = sorted(s1, key=lambda x:x[0], reverse=True)
        edge_target = s1[0][1]
        param = self.params[edge_target].detach()
        # avoid zero
        param[self.zeroid] = 0.
        idxs = param.argmax()
        self.determined[edge_target] = torch.eye(len(param))[idxs].float().to(param.device)
    
    def retrieve(self, key):
        key = str(key)
        if key in self.determined:
            return self.determined[key]
        return self.params[key].softmax(dim=0)
    
    def forward(self, features, key):
        if len(features) == self.n_ops - 1:
            features.insert(self.zeroid, torch.zeros_like(features[0]))
        distribution = self.retrieve(key)
        return sum([k * feature for k, feature in zip(distribution, features)])

    def normalize(self, elements):
        mins = min(elements)
        maxs = max(elements)
        if maxs - mins < 1e-4: return [0 for _ in range(len(elements))]
        return [(l - mins) / (maxs - mins) for l in elements]


if __name__ == '__main__':
    edge_group = EdgeGroup({
        'layer1': torch.randn(10),
        'layer2': torch.randn(10),
    }, 8)

    print(edge_group.params)
    print(edge_group.retrieve('layer1'))
    print(edge_group.retrieve('layer2'))
    edge_group.determine()
    print(edge_group.retrieve('layer1'))
    print(edge_group.retrieve('layer2'))
    edge_group.determine()
    print(edge_group.retrieve('layer1'))
    print(edge_group.retrieve('layer2'))
