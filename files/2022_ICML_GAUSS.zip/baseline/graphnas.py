"""
use rl to learn the correlations
"""

from collections import Counter
import time
import torch
from sampler import RNNAgent

class GraphNASAlgorithm:
    def __init__(self, space, num_layers, T, lr, device):
        self.space = space
        self.num_of_ops = len(space)
        self.sampler = RNNAgent(self.num_of_ops, num_layers, T=T).to(device)
        self.optimizer = torch.optim.Adam(self.sampler.parameters(), lr=lr)
        self.lr = lr
        self.device = device
        self.baseline = None
        self.T = T

    def train(self):
        self.sampler.train()
    
    def eval(self):
        self.sampler.eval()

    def evaluate(self, n=100):
        archs = [str(self.sample()) for i in range(n)]
        count = Counter(archs)
        print(count.most_common(3))

    @torch.no_grad()
    def sample(self):
        self.sampler.eval()
        arch, _, _, _ = self.sampler.sample(1)
        return [self.space[i] for i in arch[0]]

    def train_constraint(self, evaluate, time_limit=-1, archs=-1):
        print('constraint', time_limit, archs)
        time_begin = time.time()
        self.sampler.train()
        idxs = 0
        assert time_limit > 0 or archs > 0
        while (time_limit > 0 and time.time() - time_begin < time_limit) or (archs > 0 and idxs < archs):
            self.optimizer.zero_grad()
            arch, log_p, _, _ = self.sampler.sample(1)
            idxs += 1
            acc = evaluate([self.space[i] for i in arch[0]])
            if self.baseline is None:
                self.baseline = acc
            else:
                self.baseline = self.baseline * 0.9 + acc * 0.1
            print('now counting on arch', arch, 'idx', idxs, 'acc', acc)
            reward = torch.tensor([acc - self.baseline]).to(log_p[0].device)
            loss_REINFORCE = - reward * log_p[0]
            loss_REINFORCE.backward()
            self.optimizer.step()
