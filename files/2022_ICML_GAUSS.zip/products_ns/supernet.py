import torch
from torch.nn import Linear as Lin
from supernet.ops import op
import torch.nn.functional as F
from tqdm import tqdm

PRODUCTS = [
    'sage',
    'gatv2',
    'gin',
    'graph',
    'linear'
]

class Supernet(torch.nn.Module):
    def __init__(self, in_channels, hidden_channels, out_channels, num_layers, dropout, space=PRODUCTS, arch=None, track=True):
        super().__init__()

        if arch is not None:
            self.space = [[a] for a in arch]
        else:
            self.space = [space for _ in range(num_layers)]

        self.num_layers = num_layers
        self.dropout = dropout

        self.convs = torch.nn.ModuleList()
        self.bns = torch.nn.ModuleList()
        self.skips = torch.nn.ModuleList()

        for i in range(num_layers):
            in_c = in_channels if i == 0 else hidden_channels
            out_c = hidden_channels if i < num_layers - 1 else out_channels
            self.convs.append(torch.nn.ModuleDict({name: op(name, in_c, out_c, dropout) for name in self.space[i]}))
            self.skips.append(Lin(in_c, out_c))
            if i < num_layers - 1:
                self.bns.append(torch.nn.ModuleDict({name: torch.nn.BatchNorm1d(out_c, track_running_stats=track) for name in self.space[i]}))
            
    def reset_parameters(self):
        for conv in self.convs:
            for key in conv:
                conv[key].reset_parameters()
        for bn in self.bns:
            for key in bn:
                bn[key].reset_parameters()
        for skip in self.skips:
            skip.reset_parameters()

    def forward(self, x, adjs, arch):
        # `train_loader` computes the k-hop neighborhood of a batch of nodes,
        # and returns, for each layer, a bipartite graph object, holding the
        # bipartite edges `edge_index`, the index `e_id` of the original edges,
        # and the size/shape `size` of the bipartite graph.
        # Target nodes are also included in the source nodes so that one can
        # easily apply skip-connections or add self-loops.
        assert len(arch) == self.num_layers
        for i, (edge_index, _, size) in enumerate(adjs):
            x_target = x[:size[1]]  # Target nodes are always placed first.
            x = self.convs[i][arch[i]]((x, x_target), edge_index)
            x = x + self.skips[i](x_target)
            if i != self.num_layers - 1:
                x = self.bns[i][arch[i]](x)
                x = F.elu(x)
                x = F.dropout(x, p=self.dropout, training=self.training)
        return x.log_softmax(dim=-1)

    def inference(self, x_all, subgraph_loader, device, arch):
        pbar = tqdm(total=x_all.size(0) * self.num_layers)
        pbar.set_description('Evaluating')

        # Compute representations of nodes layer by layer, using *all*
        # available edges. This leads to faster computation in contrast to
        # immediately computing the final representations of each batch.
        total_edges = 0
        for i in range(self.num_layers):
            xs = []
            for batch_size, n_id, adj in subgraph_loader:
                edge_index, _, size = adj.to(device)
                total_edges += edge_index.size(1)
                x = x_all[n_id].to(device)
                x_target = x[:size[1]]
                x = self.convs[i][arch[i]]((x, x_target), edge_index)
                x = x + self.skips[i](x_target)

                if i != self.num_layers - 1:
                    x = self.bns[i][arch[i]](x)
                    x = F.elu(x)
                xs.append(x.cpu())

                pbar.update(batch_size)

            x_all = torch.cat(xs, dim=0)

        pbar.close()

        return x_all