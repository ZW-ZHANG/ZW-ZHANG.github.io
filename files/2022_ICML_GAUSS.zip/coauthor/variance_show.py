# every 5 epoch, load one

import os
import torch
import argparse
from sampler import RandomSampler, RLSampler
from .supernet import COAUTHOR, Supernet
# from supernet.supernet import Supernet
from torch_geometric.datasets import Coauthor
import torch_geometric.transforms as T
import numpy as np

parser = argparse.ArgumentParser()
parser.add_argument('--folder', type=str)
parser.add_argument('--mode', type=str, choices=['ais', 'plain'], default='ais')
parser.add_argument('--num_layers', type=int, default=2)
parser.add_argument('--hidden_channels', type=int, default=256)
parser.add_argument('--dataset', type=str, default='CS', choices=['CS', 'Physics'])
parser.add_argument('--dropout', type=float, default=0.5)
parser.add_argument('--device', type=int, default=0)
parser.add_argument('--repeat', type=int, default=20)
parser.add_argument('--inner', type=int, default=12)
parser.add_argument('--consider-ratio', action='store_true')

args = parser.parse_args()

add_pre = (args.dataset == 'Physics')
folder = args.folder
mode = args.mode

if mode == 'ais':
    sampler = RLSampler(COAUTHOR, 2, 'cuda', 'acc')
    sampler.fitted = True
else:
    sampler = RandomSampler(COAUTHOR, 2)

device = f'cuda:{args.device}' if torch.cuda.is_available() else 'cpu'
device = torch.device(device)

dataset = Coauthor(os.path.expanduser("~/dataset/pyg"), name=args.dataset, transform=T.NormalizeFeatures())

data = dataset[0]
data = data.to(device)

split_idx = torch.load(f"models/coauthor/{args.dataset}/split.bin")

for key in split_idx: split_idx[key] = split_idx[key].to(device)

train_idx = split_idx['train'].to(device)
valid_idx = split_idx['valid'].to(device)
test_idx = split_idx['test'].to(device)

model = Supernet(args.num_layers, data.x.size(-1), dataset.num_classes, args.hidden_channels, args.dropout, track=False, add_pre=add_pre).cuda()

@torch.no_grad()
def evaluate(archs):
    accs = []
    for arc in archs:
        out = model(data, arc)[valid_idx]
        acc = (out.argmax(dim=-1) == data.y[valid_idx]).float().mean()
        accs.append(acc.item())
    return accs

for e in range(5, 101, 5):
    if os.path.exists(os.path.join(args.folder, f"sampler/{e}-sampler.pth")):
        sampler.sampler.load_state_dict(torch.load(os.path.join(args.folder, f"sampler/{e}-sampler.pth")))
    model.load_state_dict(torch.load(os.path.join(args.folder, f"models/{e}.pt")))
    model.eval()
    sampler.eval()

    # count mean and variance

    estimation = []

    for _ in range(args.repeat):
        archs = sampler.samples(args.inner)
        ratios = [a[1] for a in archs]
        accs = evaluate([a[0] for a in archs])

        if args.consider_ratio:
            accs = [(a * r) for a, r in zip(accs, ratios)]
    
        estimated_acc = np.mean(accs)
    
        estimation.append(estimated_acc)
    print(e, np.mean(estimation), np.std(estimation))
