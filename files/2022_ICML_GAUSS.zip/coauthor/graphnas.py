from functools import partial
import torch
import torch.nn.functional as F
from baseline.graphnas import GraphNASAlgorithm
from .supernet import Supernet, COAUTHOR
import os
from torch_geometric.datasets import Coauthor
import torch_geometric.transforms as T

def gen_model(arch, inputs, outputs, args):
    return Supernet(args.num_layers, inputs, outputs, args.n_hidden, args.dropout, COAUTHOR, arch, add_pre=args.add_pre).to(args.device)

def arch2score(arch, data, inc, ouc, args):
    model = gen_model(arch, inc, ouc, args)
    # train 100 epoch, find the best
    best_acc = 0.
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
    for e in range(args.epochs):
        model.train()
        optimizer.zero_grad()
        out = model(data, arch)[data.train_mask]
        loss = F.nll_loss(out, data.y[data.train_mask])
        loss.backward()
        optimizer.step()

        # evaluate
        model.eval()
        out = model(data, arch)
        val_acc = (out[data.valid_mask].argmax(dim=1) == data.y[data.valid_mask]).float().mean()
        if val_acc > best_acc:
            best_acc = val_acc
            # test_acc = (out[data.test_mask].argmax(dim=1) == data.y[data.test_mask]).float().mean()

    return best_acc

if __name__ == '__main__':
    import argparse
    import time
    begin_time = time.time()
    parser = argparse.ArgumentParser(description='graphnas-coauthor')
    parser.add_argument('--device', type=str, default="cuda")
    parser.add_argument('--num-layers', type=int, default=2)
    parser.add_argument('--n-hidden', type=int, default=256)
    parser.add_argument('--dataset', type=str, default='CS', choices=['CS', 'Physics'])

    parser.add_argument('--dropout', type=float, default=0.5)
    parser.add_argument('--lr', type=float, default=0.005)
    parser.add_argument('--epochs', type=int, default=100)
    parser.add_argument('--gnas-lr', type=float, default=0.01)
    parser.add_argument('--T', type=float, default=1)
    parser.add_argument('--time-limit', type=float, default='75', help='to be fair, we restrict the running time of graphnas')

    args = parser.parse_args()

    print(args)

    args.add_pre = args.dataset == 'Physics'

    dataset = Coauthor(os.path.expanduser("~/dataset/pyg"), name=args.dataset, transform=T.NormalizeFeatures())

    data = dataset[0]
    data = data.to(args.device)

    split_idx = torch.load(f"models/coauthor/{args.dataset}/split.bin")

    for key in split_idx: split_idx[key] = split_idx[key].to(args.device)

    train_idx = split_idx['train'].to(args.device)
    valid_idx = split_idx['valid'].to(args.device)
    test_idx = split_idx['test'].to(args.device)

    data.train_mask = train_idx
    data.valid_mask = valid_idx
    data.test_mask = test_idx

    graphnas = GraphNASAlgorithm(COAUTHOR, args.num_layers, args.T, args.gnas_lr, args.device)
    graphnas.train_constraint(partial(arch2score, data=data, args=args, inc=data.x.size(1), ouc=dataset.num_classes), args.time_limit - time.time() + begin_time)
    graphnas.evaluate()
