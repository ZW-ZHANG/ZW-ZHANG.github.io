# search

```cmd
python -m coauthor.train --eval-epoch -1 --epochs 100 --use-sampler --warm-up 0.6 --T 100 --use-curriculum --name T100 --dataset Physics/CS
python -m coauthor.search --model ./logs/coauthor/CS/T100-repeat-10-ais-True-gpl-True/moels/100.pt
python -m coauthor.rerun --archs "['ginv2', 'ginv2']" --dataset Physics
```

run following commands to perform final search

```cmd
python -m coauthor.train --use-curriculum --min-ratio 0.6 1.0 --eval-epoch 5 --repeat 12 --epochs 100 --use-sampler --warm-up 0.0 --no-baseline --max-clip 1.2 --epoch-sampler 10 --iter-sampler 12 --entropy 0.0001
```