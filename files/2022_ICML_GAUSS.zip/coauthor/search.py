"""
Search all architectures
"""

import argparse
from itertools import product
import os
import torch
import torch.nn.functional as F
import torch_geometric.transforms as T
from .supernet import Supernet, COAUTHOR
from torch_geometric.datasets import Coauthor
import random

def train(model, data, train_idx, optimizer, args, sampler, epoch, num_classes):
    model.train()
    optimizer.zero_grad()
    archs = sampler.samples(args.repeat)

    if args.use_curriculum:
        judgement = None
        best_acc = 0
        if epoch < args.warm_up:
            # min_ratio = args.min_ratio[0]
            min_ratio = epoch / args.epochs * (args.min_ratio[1] - args.min_ratio[0]) + args.min_ratio[0]
        else:
            min_ratio = epoch / args.epochs * (args.min_ratio[1] - args.min_ratio[0]) + args.min_ratio[0]
            # min_ratio = args.min_ratio[1]
            archs = sorted(archs, key=lambda x:x[1])
    
    for arch, score in archs:
        ratio = score if args.no_baseline else 1.
        out = model(data, arch)[train_idx]

        if args.min_clip > 0:
            ratio = max(ratio, args.min_clip)
        if args.max_clip > 0:
            ratio = min(ratio, args.max_clip)

        loss = F.nll_loss(out, data.y[train_idx], reduction="none") / args.repeat * ratio
        
        aggrement = (out.argmax(dim=1) == data.y[train_idx])
        cur_acc = aggrement.float().mean()
        if args.use_curriculum and (judgement is None or cur_acc > best_acc):
            # cal the judgement
            judgement = torch.ones_like(loss).float()
            bar = 1 / num_classes
            wrong_idxs = (~aggrement).nonzero().squeeze()
            # pass by the bar
            distributions = torch.exp(out)
            wrong_idxs = wrong_idxs[distributions[wrong_idxs].max(dim=1)[0] > min(5 * bar, 0.7)]
            sorted_idxs = distributions[wrong_idxs].max(dim=1)[0].sort(descending=True)[1][:int(args.max_ratio * out.size(0))]
            wrong_idxs = wrong_idxs[sorted_idxs]

            if min_ratio < 0:
                judgement = judgement.bool()
                judgement[wrong_idxs] = False
            else:
                judgement[wrong_idxs] = min_ratio

            loss = loss.mean()
            best_acc = cur_acc
        else:
            if not args.use_curriculum:
                loss = loss.mean()
            else:
                if min_ratio < 0: loss = loss[judgement].mean()
                else: loss = (loss * judgement).mean()


        loss.backward()
    optimizer.step()

    return loss.item()

@torch.no_grad()
def arch2score(archs, model, data, valid_idx, gradient=False):
    model.eval()
    losses = []
    accs = []
    for a in archs:
        out = model(data, a)[valid_idx]
        losses.append(F.nll_loss(out, data.y[valid_idx]).item())
        accs.append((out.argmax(1) == data.y[valid_idx]).float().mean().item())
    return losses, accs, None
        
def main():
    parser = argparse.ArgumentParser(description='gen_models')
    parser.add_argument('--device', type=int, default=0)
    parser.add_argument('--num_layers', type=int, default=2)
    parser.add_argument('--hidden_channels', type=int, default=256)
    parser.add_argument('--dataset', type=str, default='CS', choices=['CS', 'Physics'])
    parser.add_argument('--dropout', type=float, default=0.5)
    parser.add_argument('--track', action='store_true')
    parser.add_argument('--name', type=str, default='search-all')
    parser.add_argument('--model', type=str)
    parser.add_argument('--logs', type=str, default='./logs/coauthor/CS/search.log')

    args = parser.parse_args()
    print(args)

    add_pre = args.dataset == 'Physics'

    def log(strs):
        print(strs)
        open(args.logs, 'a').write(strs + '\n')

    device = f'cuda:{args.device}' if torch.cuda.is_available() else 'cpu'
    device = torch.device(device)
    
    dataset = Coauthor(os.path.expanduser("~/dataset/pyg"), name=args.dataset, transform=T.NormalizeFeatures())

    data = dataset[0]
    data = data.to(device)

    print('num features', data.x.size(1))
    print('num classes', dataset.num_classes)
    
    if not os.path.exists(f"models/coauthor/{args.dataset}/split.bin"):        
        # fix random seed of train/val/test split
        random.seed(2022)
        masks = list(range(data.num_nodes))
        random.shuffle(masks)
        fold = int(data.num_nodes * 0.1)
        train_idx = masks[:fold * 6]
        val_idx = masks[fold * 6: fold * 8]
        test_idx = masks[fold * 8:]
        split_idx = {
            'train': torch.tensor(train_idx).long(),
            'valid': torch.tensor(val_idx).long(),
            'test': torch.tensor(test_idx).long()
        }
        torch.save(split_idx, f"models/coauthor/{args.dataset}/split.bin")
    else:
        split_idx = torch.load(f"models/coauthor/{args.dataset}/split.bin")
    
    for key in split_idx: split_idx[key] = split_idx[key].to(device)

    train_idx = split_idx['train'].to(device)
    valid_idx = split_idx['valid'].to(device)
    test_idx = split_idx['test'].to(device)

    model = Supernet(args.num_layers, data.x.size(-1), dataset.num_classes, args.hidden_channels, args.dropout, track=args.track, add_pre=add_pre).cuda()
    model.load_state_dict(torch.load(args.model))

    archs_all = [a for a in product(*model.space)]
    loss, acc, _ = arch2score(archs_all, model, data, valid_idx)
    binded = [[a, l, ac] for a, l, ac in zip(archs_all, loss, acc)]

    # LOSS
    binded = sorted(binded, key=lambda x:x[1])
    
    log("LOSS")
    for i, (a, l, acc) in enumerate(binded):
        log(f"Epoch {i:03d} Acc: {acc:.4f} Loss: {l:.4f} Arch: {a}")


    # ACC
    binded = sorted(binded, key=lambda x:-x[2])
    
    log("ACC")
    for i, (a, l, acc) in enumerate(binded):
        log(f"Epoch {i:03d} Acc: {acc:.4f} Loss: {l:.4f} Arch: {a}")

if __name__ == "__main__":
    main()
