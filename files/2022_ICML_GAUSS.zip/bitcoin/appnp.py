import argparse

import torch
import torch.nn.functional as F
from torch.nn import Linear
from torch_geometric.nn import APPNP, SGConv

class SGCNet(torch.nn.Module):
    def __init__(self, indim, dim, outdim, K=3):
        super().__init__()
        self.conv1 = SGConv(indim, outdim,
                            K=K, cached=True)

    def reset_parameters(self):
        self.conv1.reset_parameters()

    def forward(self, x, edge_index):
        x = self.conv1(x, edge_index)
        return F.log_softmax(x, dim=1)

class Net(torch.nn.Module):
    def __init__(self, indim, dim, outdim, dropout=0.5, K=10, alpha=0.1):
        super().__init__()
        self.lin1 = Linear(indim, dim)
        self.lin2 = Linear(dim, outdim)
        self.prop1 = APPNP(K, alpha)
        self.dropout = dropout

    def reset_parameters(self):
        self.lin1.reset_parameters()
        self.lin2.reset_parameters()

    def forward(self, x, edge_index):
        x = F.dropout(x, p=self.dropout, training=self.training)
        x = F.relu(self.lin1(x))
        x = F.dropout(x, p=self.dropout, training=self.training)
        x = self.lin2(x)
        x = self.prop1(x, edge_index)
        return F.log_softmax(x, dim=1)

import argparse
import os
import torch
import torch.nn.functional as F
import torch_geometric.transforms as T
from utils import Logger
from coauthor.supernet import Supernet
import pickle
from torch_geometric.datasets import FacebookPagePage
import random

def train(model, data, train_idx, optimizer):
    model.train()

    optimizer.zero_grad()
    out = model(data.x, data.adj_t)[train_idx]
    loss = F.nll_loss(out, data.y.squeeze(1)[train_idx])
    loss.backward()
    optimizer.step()

    return loss.item()


def acc(pred, label):
    return (pred.argmax(dim=1) == label).float().mean().item()

@torch.no_grad()
def test(model, data, split_idx):
    model.eval()

    out = model(data.x, data.edge_index)

    return [acc(out[split_idx[key]], data.y[split_idx[key]]) for key in ['train', 'valid', 'test']]

    
        
            
def main():
    parser = argparse.ArgumentParser(description='gen_models')
    parser.add_argument('--device', type=int, default=0)
    parser.add_argument('--log_steps', type=int, default=1)
    parser.add_argument('--num_layers', type=int, default=4)
    parser.add_argument('--hidden_channels', type=int, default=256)

    parser.add_argument('--dropout', type=float, default=0.5)
    parser.add_argument('--lr', type=float, default=0.005)
    parser.add_argument('--epochs', type=int, default=100)
    parser.add_argument('--wd', type=float, default=0.0)
    parser.add_argument('--runs', type=int, default=10)
    parser.add_argument('--model', type=str, choices=['appnp', 'sgc'])

    args = parser.parse_args()

    print(args)

    device = f'cuda:{args.device}' if torch.cuda.is_available() else 'cpu'
    device = torch.device(device)

    dataset = FacebookPagePage(os.path.expanduser("~/guancy/datasets/pyg"), transform=T.NormalizeFeatures())

    data = dataset[0]
    data = data.to(device)
    
    print('num features', data.x.size(1))
    print('num classes', dataset.num_classes)
    
    if not os.path.exists(f"models/facebook/split.bin"):
        # fix random seed of train/val/test split
        random.seed(2022)
        masks = list(range(data.num_nodes))
        random.shuffle(masks)
        fold = int(data.num_nodes * 0.1)
        train_idx = masks[:fold * 6]
        val_idx = masks[fold * 6: fold * 8]
        test_idx = masks[fold * 8:]
        split_idx = {
            'train': torch.tensor(train_idx).long(),
            'valid': torch.tensor(val_idx).long(),
            'test': torch.tensor(test_idx).long()
        }
        torch.save(split_idx, f"models/facebook/split.bin")
    else:
        split_idx = torch.load(f"models/facebook/split.bin")
    
    for key in split_idx: split_idx[key] = split_idx[key].to(device)

    train_idx = split_idx['train'].to(device)
    valid_idx = split_idx['valid'].to(device)
    test_idx = split_idx['test'].to(device)

    if args.model == 'appnp':
        model = Net(data.x.size(-1), args.hidden_channels, dataset.num_classes, args.dropout).to(device)
    else:
        model = SGCNet(data.x.size(-1), None, dataset.num_classes).to(device)

    logger = Logger(args.runs, args)

    idxs = torch.cat([train_idx])
    for run in range(args.runs):
        print(sum(p.numel() for p in model.parameters()))
        
        model.reset_parameters()
        optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=args.wd)

        for epoch in range(1, args.epochs):
            model.train()
            optimizer.zero_grad()
            out = model(data.x, data.edge_index)[idxs]
            loss = F.nll_loss(out, data.y[idxs])
            loss.backward()
            optimizer.step()
            
            result = test(model, data, split_idx)
            train_acc, valid_acc, test_acc = result
        
            print(f'Run: {run + 1:02d}, '
                      f'Epoch: {epoch:02d}, '
                      f'Loss: {loss:.4f}, '
                      f'Train: {100 * train_acc:.2f}%, '
                      f'Valid: {100 * valid_acc:.2f}% '
                      f'Test: {100 * test_acc:.2f}%')
            logger.add_result(run, result)
        logger.print_statistics(run)

    logger.print_statistics()

if __name__ == "__main__":
    main()
