from baseline.sgas import DARTS, SGAS, SNAS, EdgeGroup
import os

import torch
import torch_geometric.nn as pygnn
import torch.nn.functional as F
from facebook.data import load_dataset
from supernet.conv import Conv

COAUTHOR = [
    'gatv2',
    'gcn',
    'sage',
    'linear',
    'gin',
    'graph'
]

class Supernet(torch.nn.Module):
    def __init__(self, n_layers, n_input, n_output, n_hidden, dropout, space=COAUTHOR, arch=None, track=True, add_pre=False) -> None:
        super().__init__()
        self.n_layers = n_layers
        self.n_hidden = n_hidden
        self.dropout = dropout

        self.add_pre = add_pre

        if add_pre:
            self.preprocess = torch.nn.Sequential(
                torch.nn.Linear(n_input, n_hidden),
                torch.nn.BatchNorm1d(n_hidden, track_running_stats=track),
                torch.nn.ReLU(),
                torch.nn.Dropout(dropout)
            )
        
        if arch is None:
            self.space = [space] * n_layers
        else:
            self.space = [[a] for a in arch]

        self.convs = torch.nn.ModuleList()

        for i in range(n_layers):
            in_feat = n_input if (i == 0 and not add_pre) else n_hidden
            out_feat = n_hidden if i < n_layers - 1 else n_output
            if i < n_layers - 1:
                self.convs.append(Conv(self.space[i], in_feat, out_feat, pos=2, act=F.relu, dropout=dropout, bn=True, res=False, track=track))
            else:
                self.convs.append(Conv(self.space[i], in_feat, out_feat, pos=0))

    def forward(self, data, edge_group: EdgeGroup):
        x, edge_index = data.x, data.edge_index
        if self.add_pre:
            x = self.preprocess(x)
        for i, conv in enumerate(self.convs):
            xs = [conv(x, edge_index, a) for a in self.space[i]]
            x = edge_group.forward(xs, i)
        return x.log_softmax(dim=-1)

def supernet_step(opt_supernet, supernet, edge_group, data):
    supernet.train()
    edge_group.eval()
    opt_supernet.zero_grad()
    out = supernet(data, edge_group)[data.train_mask]
    loss = F.nll_loss(out, data.y[data.train_mask])
    loss.backward()
    opt_supernet.step()

def edge_step(opt_edge, supernet, edge_group, data):
    supernet.eval()
    edge_group.train()
    opt_edge.zero_grad()
    out = supernet(data, edge_group)[data.valid_mask]
    loss = F.nll_loss(out, data.y[data.valid_mask])
    loss.backward()
    opt_edge.step()

def main():
    import argparse
    parser = argparse.ArgumentParser(description='graphnas-coauthor')
    parser.add_argument('--device', type=str, default="cuda")
    parser.add_argument('--num-layers', type=int, default=4)
    parser.add_argument('--n-hidden', type=int, default=256)

    parser.add_argument('--dropout', type=float, default=0.5)
    parser.add_argument('--lr', type=float, default=0.005)
    parser.add_argument('--edge-lr', type=float, default=3e-4)
    parser.add_argument('--epochs', type=int, default=100)
    parser.add_argument('--edge-epoch', type=int, default=5)
    parser.add_argument('--determine-epoch', type=int, default=25)
    parser.add_argument('--edge-type', type=str, choices=['darts', 'sgas', 'egan'], default='sgas')

    args = parser.parse_args()

    print(args)

    dataset, data, train_idx, valid_idx, test_idx, split_idx = load_dataset()

    data.train_mask = train_idx
    data.valid_mask = valid_idx
    data.test_mask = test_idx
    
    supernet = Supernet(args.num_layers, data.x.size(1), dataset.num_classes, args.n_hidden, args.dropout, COAUTHOR, None, add_pre=True).to(args.device)

    edge_group = {'sgas': SGAS, 'darts': DARTS, 'egan': SNAS}[args.edge_type](len(COAUTHOR), args.num_layers, -1).to(args.device)

    opt_supernet = torch.optim.Adam(supernet.parameters(), lr=args.lr)
    opt_edge = torch.optim.Adam(edge_group.parameters(), lr=args.edge_lr)

    for e in range(1, args.epochs + 1):
        supernet_step(opt_supernet, supernet, edge_group, data)

        if e % args.edge_epoch == 0:
            print('edge step at', e)
            edge_step(opt_edge, supernet, edge_group, data)
        
        if args.edge_type == 'sgas' and e % args.determine_epoch == 0:
            edge_group.determine()
            print('edge determine', e)
            print([edge_group.retrieve(i) for i in range(args.num_layers)])
            if len(edge_group.determined) == len(edge_group.params):
                break

    if args.edge_type != 'sgas': edge_group.determine()

    print([COAUTHOR[edge_group.retrieve(i).argmax()] for i in range(args.num_layers)])

if __name__ == '__main__':
    main()
