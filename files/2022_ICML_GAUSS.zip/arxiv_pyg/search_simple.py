from itertools import product
import torch
from search import EvolutionAlgorithm
import argparse
from .train import arch2score
from .supernet import ARXIV_SIMPLE
from supernet.supernet import Supernet
import os
import torch_geometric.transforms as T
from ogb.nodeproppred import PygNodePropPredDataset, Evaluator
from functools import partial
from supernet.ops import uniform_sample, mutate


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--num-layers', type=int, default=3)
    parser.add_argument('--hidden-channels', type=int, default=256)
    parser.add_argument('--dropout', type=float, default=0.5)
    parser.add_argument('--track', action='store_true')
    parser.add_argument('--share-bn', action='store_true')
    parser.add_argument('--eval-first', action='store_true')
    parser.add_argument('--model', type=str)
    parser.add_argument('--space', type=str, choices=['full', 'simple'], default='simple')
    parser.add_argument('--ea-parameters', type=int, nargs='+', default=[500, 10, 50])
    parser.add_argument('--path', type=str, default='logs/arxiv/simple-search.log')
    parser.add_argument('--no-residual', action='store_true')

    args = parser.parse_args()

    space = ARXIV_SIMPLE

    device = torch.device('cuda')
    
    dataset = PygNodePropPredDataset(name='ogbn-arxiv', root=os.path.expanduser("~/dataset/pyg"), transform=T.ToSparseTensor())
    
    data = dataset[0]
    data.adj_t = data.adj_t.to_symmetric()
    data = data.to(device)
    
    x = data.x
        
    x = x.to(device)
    adj_t = data.adj_t.to(device)
    y_true = data.y.to(device)
    
    split_idx = dataset.get_idx_split()
    train_idx = split_idx['train'].to(device)
    valid_idx = split_idx['valid'].to(device)
    test_idx = split_idx['test'].to(device)

    model = Supernet(x.size(-1), args.hidden_channels, dataset.num_classes, args.num_layers, args.dropout, space=space, track=args.track).cuda()
    model.load_state_dict(torch.load(args.model))
    evaluator = Evaluator(name='ogbn-arxiv')
        
    archs = [a for a in product(*model.space)]
    losses, accs, _ = arch2score(archs, data, model, evaluator, split_idx)
    
    binded = [(arc, los, acc) for arc, los, acc in zip(archs, losses, accs)]

    def logs(strs):
        print(strs)
        open(args.path, 'a').write(str(strs) + '\n')
    
    logs(args)
    logs("[LOSS]")
    binded = sorted(binded, key=lambda x:x[1])
    for i, (arch, los, acc) in enumerate(binded):
        logs(f'No. {i:3d} loss: {los:.4f} acc: {acc:.4f} arch: {arch}')
    
    
    logs("\n[ACC]")
    binded = sorted(binded, key=lambda x:-x[2])
    for i, (arch, los, acc) in enumerate(binded):
        logs(f'No. {i:3d} loss: {los:.4f} acc: {acc:.4f} arch: {arch}')
