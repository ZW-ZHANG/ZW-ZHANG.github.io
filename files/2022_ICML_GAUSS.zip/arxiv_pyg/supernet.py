import torch
import torch.nn.functional as F
from supernet.ops import op

ARXIV = [
    'gatv2',
    'gcn',
    'sage',
    'graph',
    'linear',
    'identity',
    'gin'
]

ARXIV_SIMPLE = [
    'gatv2',
    'gcn',
    'sage',
    'graph',
    'linear',
    'gin'
]

class Supernet(torch.nn.Module):
    def __init__(self, in_channels, hidden_channels, out_channels, num_layers,
                 dropout, space=ARXIV, arch=None, track=True, share_bn=False, residual=True, jk=True):
        super(Supernet, self).__init__()

        if arch is not None:
            self.space = [[a] for a in arch]
        else:
            self.space = [space] * num_layers
        
        self.residual = residual
        self.jk = jk

        self.convs = torch.nn.ModuleList()
        self.bns = torch.nn.ModuleList()
        self.inProj = torch.nn.Linear(in_channels, hidden_channels)
        # self.bns.append(torch.nn.BatchNorm1d(hidden_channels, track_running_stats=track))
        for i in range(num_layers):
            self.convs.append(torch.nn.ModuleDict({
                name: op(
                    name, hidden_channels, hidden_channels
                ) for name in self.space[i]}))
            if share_bn:
                bn = torch.nn.BatchNorm1d(hidden_channels, track_running_stats=track)
                self.bns.append(torch.nn.ModuleDict({name: bn for name in self.space[i]}))
            else:
                self.bns.append(torch.nn.ModuleDict({
                    name: torch.nn.BatchNorm1d(hidden_channels, track_running_stats=track)
                    for name in self.space[i]
                }))
        self.linear = torch.nn.Linear(hidden_channels, out_channels)
        self.weights = torch.nn.Parameter(torch.randn((len(self.convs))))
        self.dropout = dropout

    def reset_parameters(self):
        for conv in self.convs:
            for key in conv:
                conv[key].reset_parameters()
        
        # self.bns[0].reset_parameters()
        
        for bn in self.bns: #[1:]:
            for key in bn:
                bn[key].reset_parameters()
        self.linear.reset_parameters()
        self.inProj.reset_parameters()
        torch.nn.init.normal_(self.weights)

    
    def pretrain(self, x, adj, arch):
        out = []
        x = self.inProj(x)
        inp = x
        assert len(arch) == len(self.convs)
        for i, (conv, a) in enumerate(zip(self.convs, arch)):
            x = conv[a](x, adj)
            if self.jk or i < len(self.convs) - 1:
                x = self.bns[i][a](x)
                x = F.relu(x, inplace=True)
                x = F.dropout(x, p=self.dropout, training=self.training)
                if self.residual:
                    x = x + 0.2*inp
                out.append(x)
        if self.jk:
            sftmax = F.softmax(self.weights, dim=0)
            for i in range(len(out)):
                out[i] = out[i] * sftmax[i]
            x = sum(out)
        x = self.linear(x)
        return x
    
    def forward(self, x, adj, arch):
        x = self.pretrain(x, adj, arch)
        return x.log_softmax(dim=-1)


if __name__ == '__main__':
    from supernet.ops import uniform_sample
    import argparse
    import pickle
    
    parser = argparse.ArgumentParser()
    parser.add_argument('--num-archs', type=int, default=400)
    parser.add_argument('--layer', type=int, default=6)
    parser.add_argument('--path', type=str)
    parser.add_argument('--space', type=str, choices=['simple', 'full'], default='simple')
    args = parser.parse_args()

    if args.space == 'simple':
        space = ARXIV_SIMPLE
    else:
        space = ARXIV

    archs = []
    while len(archs) < args.num_archs:
        arch = uniform_sample(args.layer, space)
        if arch not in archs:
            archs.append(arch)

    pickle.dump(archs, open(args.path, 'wb'))
