import argparse
import os
import torch
import torch.nn.functional as F
import torch_geometric.transforms as T
from ogb.nodeproppred import PygNodePropPredDataset, Evaluator
from utils import Logger
from .supernet import ARXIV_SIMPLE
from supernet.supernet import Supernet
import pickle

def train(model, data, train_idx, optimizer, arch):
    model.train()

    optimizer.zero_grad()
    out = model(data.x, data.adj_t, arch)[train_idx]
    loss = F.nll_loss(out, data.y.squeeze(1)[train_idx])
    loss.backward()
    optimizer.step()

    return loss.item()


@torch.no_grad()
def test(model, x, y, adj, split_idx, evaluator, arch):
    model.eval()

    out = model(x, adj, arch)
    y_pred = out.argmax(dim=-1, keepdim=True)

    train_acc = evaluator.eval({
        'y_true': y[split_idx['train']],
        'y_pred': y_pred[split_idx['train']],
    })['acc']
    valid_acc = evaluator.eval({
        'y_true': y[split_idx['valid']],
        'y_pred': y_pred[split_idx['valid']],
    })['acc']
    test_acc = evaluator.eval({
        'y_true': y[split_idx['test']],
        'y_pred': y_pred[split_idx['test']],
    })['acc']

    return train_acc, valid_acc, test_acc

    
        
            
def main():
    parser = argparse.ArgumentParser(description='gen_models')
    parser.add_argument('--device', type=int, default=0)
    parser.add_argument('--log_steps', type=int, default=1)
    parser.add_argument('--num_layers', type=int, default=3)
    parser.add_argument('--hidden_channels', type=int, default=256)
    parser.add_argument('--use_node_embedding', action='store_true')

    parser.add_argument('--dropout', type=float, default=0.5)
    parser.add_argument('--lr', type=float, default=0.01)
    parser.add_argument('--epochs', type=int, default=500)
    parser.add_argument('--wd', type=float, default=0.0)
    parser.add_argument('--runs', type=int, default=10)
    parser.add_argument('--no-track', action='store_true')
    parser.add_argument('--archs', type=str, default=str(['gcn'] * 6))
    parser.add_argument('--arch-path', type=str, default='./models/arxiv/random_sample.pkl')
    parser.add_argument('--space', type=str, default='simple', choices=['simple', 'full'])

    args = parser.parse_args()

    args.space = ARXIV_SIMPLE
    args.arch = eval(args.archs)

    if isinstance(args.arch, int):
        args.arch = pickle.load(open(args.arch_path, 'rb'))[args.arch]
    print(args)

    
    device = f'cuda:{args.device}' if torch.cuda.is_available() else 'cpu'
    device = torch.device(device)

    dataset = PygNodePropPredDataset(name='ogbn-arxiv', root=os.path.expanduser("~/dataset/pyg"), transform=T.ToSparseTensor())
    
    data = dataset[0]
    data.adj_t = data.adj_t.to_symmetric()
    data = data.to(device)
    
    print('num features', data.x.size(1))
    print('num classes', dataset.num_classes)

    x = data.x
    if args.use_node_embedding:
        embedding = torch.load('embedding.pt', map_location=device)
        x = torch.cat([x, embedding], dim=-1)
        
    x = x.to(device)
    adj_t = data.adj_t.to(device)
    y_true = data.y.to(device)

    split_idx = dataset.get_idx_split()
    train_idx = split_idx['train'].to(device)
    valid_idx = split_idx['valid'].to(device)
    test_idx = split_idx['test'].to(device)

    model = Supernet(x.size(-1), args.hidden_channels, dataset.num_classes, args.num_layers, args.dropout, space=args.space, arch=args.arch, track=not args.no_track).cuda()
        
    evaluator = Evaluator(name='ogbn-arxiv')
    logger = Logger(args.runs, args)
    
    idxs = torch.cat([train_idx])
    for run in range(args.runs):
        print(sum(p.numel() for p in model.parameters()))
        
        model.reset_parameters()
        optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=args.wd)
        best_valid = 0
        best_out = None
        
        import time
        begin = time.time()
        for epoch in range(1, args.epochs):
            model.train()
            optimizer.zero_grad()
            out = model(x, adj_t, args.arch)[idxs]
            loss = F.nll_loss(out, y_true.squeeze(1)[idxs])
            result = test(model, x, y_true, adj_t, split_idx, evaluator, args.arch)
            train_acc, valid_acc, test_acc = result
        
            print(f'Run: {run + 1:02d}, '
                      f'Epoch: {epoch:02d}, '
                      f'Loss: {loss:.4f}, '
                      f'Train: {100 * train_acc:.2f}%, '
                      f'Valid: {100 * valid_acc:.2f}% '
                      f'Test: {100 * test_acc:.2f}%')
            logger.add_result(run, result)
            loss.backward()
            optimizer.step()
        logger.print_statistics(run)

    logger.print_statistics()

if __name__ == "__main__":
    main()