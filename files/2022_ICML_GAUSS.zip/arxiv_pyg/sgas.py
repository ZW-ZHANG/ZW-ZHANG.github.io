from baseline.sgas import SNAS, DARTS, SGAS
import torch_geometric.transforms as T
import os

import torch
import torch.nn.functional as F
from supernet.conv import Conv
from .supernet import ARXIV_SIMPLE
from ogb.nodeproppred import PygNodePropPredDataset
from .sgas_sample.sample import get_dataset

class Supernet(torch.nn.Module):
    def __init__(
        self,
        n_features,
        n_hidden,
        n_classes,
        n_layers,
        dropout=0.5,
        act=torch.nn.ReLU(),
        track=True,
        space=ARXIV_SIMPLE,
        arch=None
    ) -> None:
        super().__init__()
        if arch is not None:
            self.space = [[a] for a in arch]
        else:
            self.space = [space] * n_layers
        self.act = act
        self.dropout = dropout

        self.convs = torch.nn.ModuleList()

        for i in range(n_layers - 1):
            in_c = n_features if i == 0 else n_hidden
            out_c = n_hidden
            self.convs.append(Conv(self.space[i], in_c, out_c, 2, act, dropout, True, False, track))
        self.convs.append(Conv(self.space[n_layers - 1], n_hidden, n_classes, 0))

    def forward(self, x, adj, edge_group: DARTS):
        for i, conv in enumerate(self.convs):
            xs = [conv(x, adj, a) for a in self.space[i]]
            x = edge_group.forward(xs, i)
        return x.log_softmax(dim=-1)


def supernet_step(opt_supernet, supernet, edge_group, data):
    supernet.train()
    edge_group.eval()
    opt_supernet.zero_grad()
    out = supernet(data.x, data.adj_t, edge_group)[data.train_mask]
    loss = F.nll_loss(out, data.y[data.train_mask])
    loss.backward()
    opt_supernet.step()

def edge_step(opt_edge, supernet, edge_group, data):
    supernet.eval()
    edge_group.train()
    opt_edge.zero_grad()
    out = supernet(data.x, data.adj_t, edge_group)[data.valid_mask]
    loss = F.nll_loss(out, data.y[data.valid_mask])
    loss.backward()
    opt_edge.step()

def main():
    import argparse
    parser = argparse.ArgumentParser(description='sgas-arxiv')
    parser.add_argument('--device', type=str, default="cuda")
    parser.add_argument('--num-layers', type=int, default=3)
    parser.add_argument('--n-hidden', type=int, default=256)

    parser.add_argument('--dropout', type=float, default=0.5)
    parser.add_argument('--lr', type=float, default=0.01)
    parser.add_argument('--edge-lr', type=float, default=3e-4)
    parser.add_argument('--epochs', type=int, default=500)
    parser.add_argument('--edge-epoch', type=int, default=5)
    parser.add_argument('--determine-epoch', type=int, default=166)
    parser.add_argument('--edge-type', type=str, choices=['darts', 'sgas', 'egan'], default='sgas')
    parser.add_argument('--sample-ratio', type=float, default=1.0)

    args = parser.parse_args()
    print(args)

    device = args.device

    data, num_classes = get_dataset(args.sample_ratio == 1, args.sample_ratio)
    data = data.to(device)
    
    supernet = Supernet(data.x.size(1), args.n_hidden, num_classes, args.num_layers, args.dropout, track=True).cuda()

    edge_group = {'sgas': SGAS, 'darts': DARTS, 'egan': SNAS}[args.edge_type](len(ARXIV_SIMPLE), args.num_layers, -1).to(args.device)

    opt_supernet = torch.optim.Adam(supernet.parameters(), lr=args.lr)
    opt_edge = torch.optim.Adam(edge_group.parameters(), lr=args.edge_lr)

    for e in range(1, args.epochs + 1):
        supernet_step(opt_supernet, supernet, edge_group, data)

        if e % args.edge_epoch == 0:
            print('edge step at', e)
            edge_step(opt_edge, supernet, edge_group, data)
        
        if e % args.determine_epoch == 0:
            edge_group.determine()
            print('edge determine', e)
            print([edge_group.retrieve(i) for i in range(args.num_layers)])
            if len(edge_group.determined) == len(edge_group.params):
                break
    
    print([ARXIV_SIMPLE[edge_group.retrieve(i).argmax()] for i in range(args.num_layers)])

if __name__ == '__main__':
    main()
