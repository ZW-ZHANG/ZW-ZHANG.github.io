import os
import argparse
import glob

import numpy as np
import torch
import torch.nn.functional as F
from dgl import function as fn
from ogb.nodeproppred import DglNodePropPredDataset, Evaluator
from tqdm import tqdm

device = None

dataset = "ogbn-arxiv"
n_node_feats, n_classes = 0, 0


def load_data(dataset):
    global n_node_feats, n_classes

    data = DglNodePropPredDataset(name=dataset, root=os.path.expanduser("~/dataset/dgl"))
    evaluator = Evaluator(name=dataset)

    splitted_idx = data.get_idx_split()
    train_idx, val_idx, test_idx = splitted_idx["train"], splitted_idx["valid"], splitted_idx["test"]
    graph, labels = data[0]

    n_node_feats = graph.ndata["feat"].shape[1]
    n_classes = (labels.max() + 1).item()

    return graph, labels, train_idx, val_idx, test_idx, evaluator


def preprocess(graph):
    global n_node_feats

    # add reverse edges
    srcs, dsts = graph.all_edges()
    graph.add_edges(dsts, srcs)

    # add self-loop
    print(f"Total edges before adding self-loop {graph.number_of_edges()}")
    graph = graph.remove_self_loop().add_self_loop()
    print(f"Total edges after adding self-loop {graph.number_of_edges()}")

    graph.create_formats_()

    return graph


def general_outcome_correlation(graph, y0, n_prop=50, alpha=0.8, use_norm=False, post_step=None):
    with graph.local_scope():
        y = y0
        for _ in range(n_prop):
            if use_norm:
                degs = graph.in_degrees().float().clamp(min=1)
                norm = torch.pow(degs, -0.5)
                shp = norm.shape + (1,) * (y.dim() - 1)
                norm = torch.reshape(norm, shp)
                y = y * norm

            graph.srcdata.update({"y": y})
            graph.update_all(fn.copy_u("y", "m"), fn.mean("m", "y"))
            y = graph.dstdata["y"]

            if use_norm:
                degs = graph.in_degrees().float().clamp(min=1)
                norm = torch.pow(degs, 0.5)
                shp = norm.shape + (1,) * (y.dim() - 1)
                norm = torch.reshape(norm, shp)
                y = y * norm

            y = alpha * y + (1 - alpha) * y0

            if post_step is not None:
                y = post_step(y)

        return y


def evaluate(labels, pred, train_idx, val_idx, test_idx, evaluator):
    return (
        evaluator(pred[train_idx], labels[train_idx]),
        evaluator(pred[val_idx], labels[val_idx]),
        evaluator(pred[test_idx], labels[test_idx]),
    )


def run(n_prop, alpha, use_norm, graph, labels, pred, train_idx, val_idx, test_idx, evaluator):
    evaluator_wrapper = lambda pred, labels: evaluator.eval(
        {"y_pred": pred.argmax(dim=-1, keepdim=True), "y_true": labels}
    )["acc"]

    y = pred.clone()
    y[train_idx] = F.one_hot(labels[train_idx], n_classes).float().squeeze(1)
    # dy = torch.zeros(graph.number_of_nodes(), n_classes, device=device)
    # dy[train_idx] = F.one_hot(labels[train_idx], n_classes).float().squeeze(1) - pred[train_idx]

    _train_acc, origin_val_acc, origin_test_acc = evaluate(labels, y, train_idx, val_idx, test_idx, evaluator_wrapper)

    # print("train acc:", _train_acc)
    # print("original val acc:", origin_val_acc)
    # print("original test acc:", origin_test_acc)

    # NOTE: Only "smooth" is performed here.
    # smoothed_dy = general_outcome_correlation(
    #     graph, dy, alpha=args.alpha1, use_norm=args.use_norm, post_step=lambda x: x.clamp(-1, 1)
    # )

    # y[train_idx] = F.one_hot(labels[train_idx], n_classes).float().squeeze(1)
    # smoothed_dy = smoothed_dy
    # y = y + args.alpha2 * smoothed_dy  # .clamp(0, 1)

    smoothed_y = general_outcome_correlation(
        graph, y, n_prop=n_prop, alpha=alpha, use_norm=use_norm, post_step=lambda x: x.clamp(0, 1)
    )

    _train_acc, val_acc, test_acc = evaluate(labels, smoothed_y, train_idx, val_idx, test_idx, evaluator_wrapper)

    # print("train acc:", _train_acc)
    # print("val acc:", val_acc)
    # print("test acc:", test_acc)

    return origin_val_acc, origin_test_acc, val_acc, test_acc

def derive_cs(graph, labels, train_idx, val_idx, test_idx, evaluator, use_norm=True, alpha=0.73, n_prop=8, folder='models/arxiv/ablation-prediction'):
    device = torch.device(f"cuda")

    # run
    best_idxs = [177, 131, 149, 130, 138, 122, 116, 141, 107, 139]
    origin_val_accs, origin_test_accs, val_accs, test_accs = [], [], [], []
    previous_vals, previous_tests = [], []

    for repeat in range(10):
        best_origin_acc = best_acc = 0
        iters = range(1, 500)
        for epoch in iters:
            path = os.path.join(folder, f"{repeat}-{epoch}.pt")
            pred = torch.load(path).to(device)
            pred = pred.softmax(dim=-1)
            origin_val_acc, origin_test_acc, val_acc, test_acc = run(n_prop, alpha, use_norm, graph, labels, pred, train_idx, val_idx, test_idx, evaluator)
            if origin_val_acc > best_origin_acc:
                best_origin_acc = origin_val_acc
                origin_test = origin_test_acc
                previous_best_acc = val_acc
                previous_cur_test = test_acc
                best_epoch = epoch
            if val_acc > best_acc:
                best_acc = val_acc
                cur_test = test_acc
                best_epoch_2 = epoch
        origin_val_accs.append(best_origin_acc)
        origin_test_accs.append(origin_test)
        val_accs.append(best_acc)
        test_accs.append(cur_test)
        previous_vals.append(previous_best_acc)
        previous_tests.append(previous_cur_test)
    return np.mean(val_accs), np.mean(test_accs)


def hpo():
    device = torch.device(f"cuda")

    # load data & preprocess
    graph, labels, train_idx, val_idx, test_idx, evaluator = load_data(dataset)
    graph = preprocess(graph)

    graph, labels, train_idx, val_idx, test_idx = map(
        lambda x: x.to(device), (graph, labels, train_idx, val_idx, test_idx)
    )

    alphas = [0.1 * i for i in range(1, 10)]
    n_props = list(range(1, 11))
    
    from itertools import product

    val1, test1 = 0., 0.
    a1 = n1 = a2 = n2 = None
    val2, test2 = 0., 0.
    for alpha, n_prop in product(alphas, n_props):
        val, test = derive_cs(graph, labels, train_idx, val_idx, test_idx, evaluator, True, alpha, n_prop, "models/arxiv/ablation-prediction-student")
        if val > val1:
            val1, test1 = val, test
            val1 = val
            a1, n1 = alpha, n_prop
        if test > test2:
            val2, test2 = val, test
            test2 = test
            a2, n2 = alpha, n_prop
        print('hp: {} {} -> {:.4f} {:.4f} | {} {} -> {:.4f} {:.4f} | {} {} -> {:.4f} {:.4f}'.format(
            alpha, n_prop, val, test,
            a1, n1, val1, test1,
            a2, n2, val2, test2
        ))

def main():
    global device

    argparser = argparse.ArgumentParser(description="implementation of C&S)")
    argparser.add_argument("--cpu", action="store_true", help="CPU mode. This option overrides --gpu.")
    argparser.add_argument("--gpu", type=int, default=0, help="GPU device ID.")
    argparser.add_argument("--use-norm", action="store_true", help="Use symmetrically normalized adjacency matrix.")
    argparser.add_argument("--alpha", type=float, default=0.73, help="alpha")
    argparser.add_argument("--n-prop", type=int, default=8)
    # rgparser.add_argument("--pred-files", type=str, default="../output2/*.pt", help="address of prediction files")
    argparser.add_argument("--folder", type=str, default='models/arxiv/ablation-prediction')
    args = argparser.parse_args()

    if args.cpu:
        device = torch.device("cpu")
    else:
        device = torch.device(f"cuda:{args.gpu}")

    # load data & preprocess
    graph, labels, train_idx, val_idx, test_idx, evaluator = load_data(dataset)
    graph = preprocess(graph)

    graph, labels, train_idx, val_idx, test_idx = map(
        lambda x: x.to(device), (graph, labels, train_idx, val_idx, test_idx)
    )

    # run
    best_idxs = [177, 131, 149, 130, 138, 122, 116, 141, 107, 139]
    origin_val_accs, origin_test_accs, val_accs, test_accs = [], [], [], []
    previous_vals, previous_tests = [], []

    for repeat in range(10):
        best_origin_acc = best_acc = 0
        iters = tqdm(range(1, 500))
        for epoch in iters:
            path = os.path.join(args.folder, f"{repeat}-{epoch}.pt")
            pred = torch.load(path).to(device)
            pred = pred.softmax(dim=-1)
            origin_val_acc, origin_test_acc, val_acc, test_acc = run(args.n_prop, args.alpha, args.use_norm, graph, labels, pred, train_idx, val_idx, test_idx, evaluator)
            if origin_val_acc > best_origin_acc:
                best_origin_acc = origin_val_acc
                origin_test = origin_test_acc
                previous_best_acc = val_acc
                previous_cur_test = test_acc
                best_epoch = epoch
            if val_acc > best_acc:
                best_acc = val_acc
                cur_test = test_acc
                best_epoch_2 = epoch
            iters.set_postfix_str('o {:.4f} {:.4f} p {:.4f} {:.4f} c {:.4f} {:.4f}'.format(best_origin_acc, origin_test, previous_best_acc, previous_cur_test, best_acc, cur_test))
        origin_val_accs.append(best_origin_acc)
        origin_test_accs.append(origin_test)
        val_accs.append(best_acc)
        test_accs.append(cur_test)
        previous_vals.append(previous_best_acc)
        previous_tests.append(previous_cur_test)
        print('best idxs\n', best_epoch, best_epoch_2)

    print(args)
    print(f"Runned {len(val_accs)} times")
    print("Val Accs:", val_accs)
    print("Test Accs:", test_accs)
    print(f"Average original val accuracy: {np.mean(origin_val_accs)} ± {np.std(origin_val_accs)}")
    print(f"Average original test accuracy: {np.mean(origin_test_accs)} ± {np.std(origin_test_accs)}")
    print(f"Average previous val accuracy: {np.mean(previous_vals)} ± {np.std(previous_vals)}")
    print(f"Average previous test accuracy: {np.mean(previous_tests)} ± {np.std(previous_tests)}")
    print(f"Average val accuracy: {np.mean(val_accs)} ± {np.std(val_accs)}")
    print(f"Average test accuracy: {np.mean(test_accs)} ± {np.std(test_accs)}")


if __name__ == '__main__':
    main()
    # hpo()
