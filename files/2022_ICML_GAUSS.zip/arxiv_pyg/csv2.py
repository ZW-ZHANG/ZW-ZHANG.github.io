from utils.cs2 import CorrectAndSmooth
import argparse
import os
import torch
import torch_geometric.transforms as T
from ogb.nodeproppred import PygNodePropPredDataset, Evaluator
import numpy as np
from tqdm import tqdm

argparser = argparse.ArgumentParser(description="implementation of C&S)")
argparser.add_argument("--cpu", action="store_true", help="CPU mode. This option overrides --gpu.")
argparser.add_argument("--gpu", type=int, default=0, help="GPU device ID.")
argparser.add_argument("--use-norm", action="store_true", help="Use symmetrically normalized adjacency matrix.")
argparser.add_argument("--alpha", type=float, default=0.73, help="alpha")
argparser.add_argument("--n-prop", type=int, default=8)
# rgparser.add_argument("--pred-files", type=str, default="../output2/*.pt", help="address of prediction files")
argparser.add_argument("--folder", type=str, default='models/arxiv/ablation-prediction')
args = argparser.parse_args()

@torch.no_grad()
def test(y_soft):
    y_pred = y_soft.argmax(dim=-1, keepdim=True)

    train_acc = evaluator.eval({
        'y_true': data.y[split_idx['train']],
        'y_pred': y_pred[split_idx['train']],
    })['acc']
    valid_acc = evaluator.eval({
        'y_true': data.y[split_idx['valid']],
        'y_pred': y_pred[split_idx['valid']],
    })['acc']
    test_acc = evaluator.eval({
        'y_true': data.y[split_idx['test']],
        'y_pred': y_pred[split_idx['test']],
    })['acc']

    return train_acc, valid_acc, test_acc, y_soft

dataset = PygNodePropPredDataset(name='ogbn-arxiv', root=os.path.expanduser("~/dataset/pyg"), transform=T.ToSparseTensor())

device = torch.device('cuda')

data = dataset[0]
data = data.to(device)
data.adj_t = data.adj_t.to_symmetric()
# train_idx = train_idx.to(device)
split_idx = dataset.get_idx_split()

evaluator = Evaluator(name='ogbn-arxiv')
# evaluator = Evaluator(name='ogbn-products')

train_idx = split_idx['train']
test_idx = split_idx['test']

x, y = data.x.to(device), data.y.to(device)
train_idx = split_idx['train'].to(device)
val_idx = split_idx['valid'].to(device)
test_idx = split_idx['test'].to(device)
x_train, y_train = x[train_idx], y[train_idx]

adj_t = data.adj_t.to(device)
deg = adj_t.sum(dim=1).to(torch.float)
deg_inv_sqrt = deg.pow_(-0.5)
deg_inv_sqrt[deg_inv_sqrt == float('inf')] = 0
DAD = deg_inv_sqrt.view(-1, 1) * adj_t * deg_inv_sqrt.view(1, -1)
DA = deg_inv_sqrt.view(-1, 1) * deg_inv_sqrt.view(-1, 1) * adj_t
AD = adj_t * deg_inv_sqrt.view(-1, 1) * deg_inv_sqrt.view(-1, 1)

# run
origin_val_accs, origin_test_accs, val_accs, test_accs = [], [], [], []

for repeat in range(10):
    best_origin_acc = best_acc = 0
    iters = tqdm(range(1, 500))
    for epoch in iters:
        path = os.path.join(args.folder, f"{repeat}-{epoch}.pt")
        pred = torch.load(path).to(device)
        pred = pred.softmax(dim=-1)
        _, origin_val_acc, origin_test_acc, _ = test(pred)
        post = CorrectAndSmooth(num_correction_layers=50, correction_alpha=0.7,
                                        num_smoothing_layers=50, smoothing_alpha=0.7,
                                        autoscale=False, scale=1.)

        y_soft = post.correct(pred, y_train, train_idx, DAD)
        y_soft = post.smooth(y_soft, y_train, train_idx, DAD)

        _, val_acc, test_acc, _ = test(y_soft)

        if origin_val_acc > best_origin_acc:
            best_origin_acc = origin_val_acc
            origin_test = origin_test_acc
        if val_acc > best_acc:
            best_acc = val_acc
            cur_test = test_acc
        iters.set_postfix_str('oval {:.4f} otest {:.4f} cval {:.4f} ctest {:.4f}'.format(best_origin_acc, origin_test, best_acc, cur_test))
    origin_val_accs.append(best_origin_acc)
    origin_test_accs.append(origin_test)
    val_accs.append(best_acc)
    test_accs.append(cur_test)

print(args)
print(f"Runned {len(val_accs)} times")
print("Val Accs:", val_accs)
print("Test Accs:", test_accs)
print(f"Average original val accuracy: {np.mean(origin_val_accs)} ± {np.std(origin_val_accs)}")
print(f"Average original test accuracy: {np.mean(origin_test_accs)} ± {np.std(origin_test_accs)}")
print(f"Average val accuracy: {np.mean(val_accs)} ± {np.std(val_accs)}")
print(f"Average test accuracy: {np.mean(test_accs)} ± {np.std(test_accs)}")
