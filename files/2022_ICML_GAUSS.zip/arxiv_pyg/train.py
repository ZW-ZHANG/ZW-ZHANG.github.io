"""
Train a more consistency supernet
"""

import argparse
import os
from scipy.stats.stats import kendalltau
import torch
import torch.nn.functional as F
import torch_geometric.transforms as T
from ogb.nodeproppred import PygNodePropPredDataset, Evaluator
from utils import read_all
from .supernet import Supernet, ARXIV, ARXIV_SIMPLE
from sampler import RLSampler, RandomSampler
from tqdm import tqdm
from functools import partial
import numpy as np
import random


@torch.no_grad()
def arch2score(arcs, data, model, evaluator, split_idx, gradient=False):
    assert not gradient
    model.eval()

    accs, losses = [], []
    for arch in tqdm(arcs):
        out = model(data.x, data.adj_t, arch)
        y_pred = out.argmax(dim=-1, keepdim=True)

        valid_acc = evaluator.eval({
            'y_true': data.y[split_idx['valid']],
            'y_pred': y_pred[split_idx['valid']],
        })['acc']
        
        accs.append(valid_acc)
        loss_val = F.nll_loss(out[split_idx["valid"]], data.y.squeeze(1)[split_idx["valid"]])
        losses.append(loss_val.item())

    print('acc stat: min {} mean {} max {}'.format(min(accs), np.mean(accs), max(accs)))
    return losses, accs, None

def main():
    parser = argparse.ArgumentParser(description='gen_models')
    parser.add_argument('--name', type=str, default='full')
    parser.add_argument('--device', type=int, default=0)
    parser.add_argument('--log-steps', type=int, default=1)
    parser.add_argument('--num-layers', type=int, default=6)
    parser.add_argument('--hidden-channels', type=int, default=128)
    parser.add_argument('--use-node-embedding', action='store_true')
    parser.add_argument('--no-residual', action='store_true')
    parser.add_argument('--no-jk', action='store_true')

    parser.add_argument('--dropout', type=float, default=0.5)
    parser.add_argument('--lr', type=float, default=0.01)
    parser.add_argument('--epochs', type=int, default=500)
    parser.add_argument('--wd', type=float, default=0.0)
    parser.add_argument('--track', action='store_true')
    parser.add_argument('--save-epoch', type=int, default=50)
    parser.add_argument('--repeat', type=int, default=6)
    parser.add_argument('--eval-epoch', type=int, default=-1)
    parser.add_argument('--share-bn', action='store_true')
    parser.add_argument('--eval-first', action='store_true')
    parser.add_argument('--restore-epoch', type=int, default=-1)
    parser.add_argument('--restore-folder', type=str)
    parser.add_argument('--space', type=str, choices=['full', 'simple'], default='simple')

    # arch sampler
    parser.add_argument('--use-sampler', action='store_true')
    parser.add_argument("--sampler-fit", type=int, default=5)
    parser.add_argument("--T", type=float, default=1.0)
    parser.add_argument("--no-baseline", action="store_true", help="whether to force multiplying 1.")
    parser.add_argument("--restart", type=int, default=-1)
    parser.add_argument("--warm-up", type=float, default=0.4)
    parser.add_argument("--lr-sampler", type=float, default=1e-3)
    parser.add_argument("--epoch-sampler", type=int, default=5)
    parser.add_argument("--iter-sampler", type=int, default=7)
    parser.add_argument("--entropy", type=float, default=0.0)
    parser.add_argument("--max-clip", type=float, default=-1)
    parser.add_argument('--min-clip', type=float, default=-1)

    # curriculum
    parser.add_argument('--use-curriculum', action='store_true')
    parser.add_argument("--max-ratio", type=float, default=0.2)
    parser.add_argument("--min-ratio", type=float, nargs="+", default=[0.2, 1.0])

    args = parser.parse_args()

    # fix seed
    seed = 2022
    os.environ['PYTHONHASHSEED'] = str(seed)
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

    _space_str = args.space
    if args.space == 'simple':
        args.space = ARXIV_SIMPLE
    else:
        args.space = ARXIV
    args.warm_up = int(args.warm_up * args.epochs)
    print(args)

    if args.eval_epoch > 0:
        all_logs = read_all('./logs/arxiv/baseline/', prefix='simple-' if _space_str == 'simple' else '', end=300 if _space_str == 'simple' else 400)
        archs_gt = list(map(lambda x:x[0], all_logs))
        vals_gt = list(map(lambda x:x[1], all_logs))
        tests_gt = list(map(lambda x:x[2], all_logs))

    folder_name = f'models/arxiv/supernet/{args.name}-{_space_str}-res-{not args.no_residual}-jk-{not args.no_jk}-{args.num_layers}-repeat-{args.repeat}-pr-{args.use_curriculum}-ratio-{args.max_ratio}-{args.min_ratio[0]}-{args.min_ratio[1]}-sbn-{args.share_bn}'

    if args.restore_epoch > 0 and args.restore_folder is not None:
        folder_name += f'-restore-{args.restore_epoch}'

    if args.use_sampler:
        sampler = RLSampler(
            args.space, args.num_layers,
            epochs=args.epoch_sampler,
            iter=args.iter_sampler,
            lr=args.lr_sampler,
            T=args.T,
            entropy=args.entropy
        )
        folder_name += '-RL-{}-{}-{}-{}-{}-{}-{}-{}-b-{}-rs-{}-{}'.format(args.epoch_sampler, args.iter_sampler, args.lr_sampler, args.T, args.entropy, args.warm_up, args.min_clip, args.max_clip, not args.no_baseline, args.restart, args.sampler_fit)
    else:
        sampler = RandomSampler(args.space, args.num_layers)
        folder_name += '-RANDOM'

    os.makedirs(folder_name)
    os.makedirs(os.path.join(folder_name, "sampler"))
    os.makedirs(os.path.join(folder_name, "models"))

    def log(strs):
        strs = str(strs)
        print(strs)
        open(os.path.join(folder_name, "train.log"), "a").write(strs + '\n')
    
    log(args)

    device = f'cuda:{args.device}' if torch.cuda.is_available() else 'cpu'
    device = torch.device(device)

    dataset = PygNodePropPredDataset(name='ogbn-arxiv', root=os.path.expanduser("~/dataset/pyg"), transform=T.ToSparseTensor())
    
    data = dataset[0]
    data.adj_t = data.adj_t.to_symmetric()
    data = data.to(device)
    
    x = data.x
    if args.use_node_embedding:
        embedding = torch.load('embedding.pt', map_location=device)
        x = torch.cat([x, embedding], dim=-1)
        
    x = x.to(device)
    adj_t = data.adj_t.to(device)
    y_true = data.y.to(device)
    
    split_idx = dataset.get_idx_split()
    train_idx = split_idx['train'].to(device)
    valid_idx = split_idx['valid'].to(device)
    test_idx = split_idx['test'].to(device)

    model = Supernet(x.size(-1), args.hidden_channels, dataset.num_classes, args.num_layers, args.dropout, args.space, track=args.track, share_bn=args.share_bn, residual=not args.no_residual, jk=not args.no_jk).cuda()
    evaluator = Evaluator(name='ogbn-arxiv')
    
    idxs = torch.cat([train_idx])
    log(sum(p.numel() for p in model.parameters()))
    
    model.reset_parameters()
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=args.wd)

    evaled_epoch = -1
    sampler_fit_time = 0

    if args.restore_epoch > 0 and args.restore_folder is not None:
        log('restore from {} at epoch {}'.format(args.restore_folder, args.restore_epoch))
        model.load_state_dict(torch.load(os.path.join(args.restore_folder, f'{args.restore_epoch}.pt')))
        if os.path.exists(os.path.join(args.restore_folder, f"{args.restore_epoch}.opt")):
            optimizer.load_state_dict(torch.load(os.path.join(args.restore_folder, f"{args.restore_epoch}.opt")))
        
        if args.use_sampler and args.restore_epoch % args.sampler_fit == 0 and args.restore_epoch >= args.warm_up and args.restore_epoch < args.epochs:
            # log(f"Epoch: {epoch:02d}, fitting the sampler...")
            # if args.restart: sampler.restart()
            sampler_fit_time += 1
            if args.restart > 0 and sampler_fit_time % args.restart == 0:
                log('\nrestart\n')
                sampler.restart()
            sampler.fit(partial(arch2score, data=data, model=model, evaluator=evaluator, split_idx=split_idx))
            sampler.log(print)
            sampler.save(os.path.join(folder_name, "sampler"), args.restore_epoch)
            if args.eval_epoch > 0:
                scores = sampler.evaluate(archs_gt)
            
            if evaled_epoch != args.restore_epoch and args.eval_epoch > 0:
                losses, accs, _ = arch2score(archs_gt, data, model, evaluator, split_idx)
                log(
                    '*************** '
                    f'Epoch: {args.restore_epoch:02d}, val tau: {- kendalltau(losses, vals_gt)[0]:.4f} {kendalltau(accs, vals_gt)[0]:.4f} '
                    f'test tau: {- kendalltau(losses, tests_gt)[0]:.4f} {kendalltau(accs, tests_gt)[0]:.4f} '
                    '***************'
                )
                evaled_epoch = args.restore_epoch
            
            if args.eval_epoch > 0:
                log(f'Sampler Epoch: {args.restore_epoch:02d}, {kendalltau(scores, vals_gt)[0]:.4f} {kendalltau(scores, tests_gt)[0]:.4f} {kendalltau(scores, accs)[0]:.4f}')

    if args.eval_first:
        if evaled_epoch != args.restore_epoch:
            losses, accs, _ = arch2score(archs_gt, data, model, evaluator, split_idx)
            evaled_epoch = args.restore_epoch
            log(
                f'Epoch: {args.restore_epoch:02d}, val tau: {- kendalltau(losses, vals_gt)[0]:.4f} {kendalltau(accs, vals_gt)[0]:.4f} '
                f'test tau: {- kendalltau(losses, tests_gt)[0]:.4f} {kendalltau(accs, tests_gt)[0]:.4f}'
            )

    for epoch in tqdm(range(max(1, 1 + args.restore_epoch), args.epochs + 1)):
        model.train()
        optimizer.zero_grad()
        # sample repeat archs
        archs = sampler.samples(args.repeat)

        if args.use_curriculum:
            judgement = None
            best_acc = 0
            if epoch < args.warm_up:
                # min_ratio = args.min_ratio[0]
                min_ratio = epoch / args.epochs * (args.min_ratio[1] - args.min_ratio[0]) + args.min_ratio[0]
            else:
                min_ratio = epoch / args.epochs * (args.min_ratio[1] - args.min_ratio[0]) + args.min_ratio[0]
                # min_ratio = args.min_ratio[1]
                archs = sorted(archs, key=lambda x:x[1])
        
        for arch, score in archs:
            ratio = score if args.no_baseline else 1.
            if args.min_clip > 0:
                ratio = max(ratio, args.min_clip)
            if args.max_clip > 0:
                ratio = min(ratio, args.max_clip)
            out = model(x, adj_t, arch)[idxs]
            loss = F.nll_loss(out, y_true.squeeze(1)[idxs], reduction="none") / args.repeat * ratio
            aggrement = (out.argmax(dim=1) == y_true.squeeze(1)[idxs])
            cur_acc = aggrement.float().mean()
            if args.use_curriculum and (judgement is None or cur_acc > best_acc):
                # cal the judgement
                judgement = torch.ones_like(loss).float()
                bar = 1 / dataset.num_classes
                wrong_idxs = (~aggrement).nonzero().squeeze()
                # pass by the bar
                distributions = torch.exp(out)
                wrong_idxs = wrong_idxs[distributions[wrong_idxs].max(dim=1)[0] > min(5 * bar, 0.7)]
                sorted_idxs = distributions[wrong_idxs].max(dim=1)[0].sort(descending=True)[1][:int(args.max_ratio * out.size(0))]
                wrong_idxs = wrong_idxs[sorted_idxs]

                if min_ratio < 0:
                    judgement = judgement.bool()
                    judgement[wrong_idxs] = False
                else:
                    judgement[wrong_idxs] = min_ratio

                loss = loss.mean()
                best_acc = cur_acc
            else:
                if not args.use_curriculum:
                    loss = loss.mean()
                else:
                    if min_ratio < 0: loss = loss[judgement].mean()
                    else: loss = (loss * judgement).mean()

            loss.backward()
        optimizer.step()

        if args.eval_epoch > 0 and epoch % args.eval_epoch == 0:
            # evaluate the current models
            evaled_epoch = epoch
            losses, accs, _ = arch2score(archs_gt, data, model, evaluator, split_idx)
            log(
                '*************** '
                f'Epoch: {epoch:02d}, val tau: {- kendalltau(losses, vals_gt)[0]:.4f} {kendalltau(accs, vals_gt)[0]:.4f} '
                f'test tau: {- kendalltau(losses, tests_gt)[0]:.4f} {kendalltau(accs, tests_gt)[0]:.4f} '
                '***************'
            )

        if args.use_sampler and epoch % args.sampler_fit == 0 and epoch >= args.warm_up and epoch < args.epochs:
            # log(f"Epoch: {epoch:02d}, fitting the sampler...")
            # if args.restart: sampler.restart()
            sampler_fit_time += 1
            if args.restart > 0 and sampler_fit_time % args.restart == 0:
                log('\nrestart\n')
                sampler.restart()
            sampler.fit(partial(arch2score, data=data, model=model, evaluator=evaluator, split_idx=split_idx))
            sampler.log(print)
            sampler.save(os.path.join(folder_name, "sampler"), epoch)
            if args.eval_epoch > 0:
                scores = sampler.evaluate(archs_gt)
            
            if evaled_epoch != epoch and args.eval_epoch > 0:
                losses, accs, _ = arch2score(archs_gt, data, model, evaluator, split_idx)
                log(
                    '*************** '
                    f'Epoch: {epoch:02d}, val tau: {- kendalltau(losses, vals_gt)[0]:.4f} {kendalltau(accs, vals_gt)[0]:.4f} '
                    f'test tau: {- kendalltau(losses, tests_gt)[0]:.4f} {kendalltau(accs, tests_gt)[0]:.4f} '
                    '***************'
                )
                evaled_epoch = epoch
            
            if args.eval_epoch > 0:
                log(f'Sampler Epoch: {epoch:02d}, {kendalltau(scores, vals_gt)[0]:.4f} {kendalltau(scores, tests_gt)[0]:.4f} {kendalltau(scores, accs)[0]:.4f}')

        if epoch % args.save_epoch == 0:
            torch.save(model.state_dict(), os.path.join(folder_name, "models", f"{epoch}.pt"))
            torch.save(optimizer.state_dict(), os.path.join(folder_name, "models", f"{epoch}.opt"))

if __name__ == "__main__":
    main()
