import torch
import torch_geometric.utils as pygutil
import torch_geometric.transforms as T
import os
from ogb.nodeproppred import PygNodePropPredDataset
from littleballoffur import PageRankBasedSampler

def get_dataset(full=False, node_number=0.15, to_sparse=True):

    dataset = PygNodePropPredDataset(name='ogbn-arxiv', root=os.path.expanduser("~/dataset/pyg"))
    num_classes = dataset.num_classes
    data = dataset[0]
    data.y = data.y[:,0]

    split_idx = dataset.get_idx_split()
    train_idx = split_idx['train']
    valid_idx = split_idx['valid']
    test_idx = split_idx['test']

    data.train_mask = torch.zeros(len(data.y)).bool()
    data.valid_mask = torch.zeros(len(data.y)).bool()
    data.test_mask = torch.zeros(len(data.y)).bool()

    data.train_mask[train_idx] = True
    data.valid_mask[valid_idx] = True
    data.test_mask[test_idx] = True

    if full:
        if to_sparse:
            data = T.ToSparseTensor()(data)
            data.adj_t = data.adj_t.to_symmetric()
        return data, num_classes
    
    network = pygutil.to_networkx(data, node_attrs=['x', 'train_mask', 'valid_mask', 'test_mask', 'y'], to_undirected=True, remove_self_loops=True)
    sampler = PageRankBasedSampler(int(network.number_of_nodes() * node_number))
    network_sampled = sampler.sample(network)
    data = pygutil.from_networkx(network_sampled)
    data.edge_index, _ = pygutil.add_self_loops(data.edge_index)
    data.edge_index = pygutil.to_undirected(data.edge_index)
    if to_sparse:
        data = T.ToSparseTensor()(data)
        data.adj_t = data.adj_t.to_symmetric()
    return data, num_classes


if __name__ == '__main__':
    data = get_dataset()
    import pdb
    pdb.set_trace()
