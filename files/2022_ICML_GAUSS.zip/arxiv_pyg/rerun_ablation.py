import argparse
import os
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch_geometric.transforms as T
from ogb.nodeproppred import PygNodePropPredDataset, Evaluator
from utils import Logger
from .supernet import ARXIV_SIMPLE
from supernet.supernet import Supernet
import pickle

def loss_kd_only(all_out,teacher_all_out,temperature):
    T = temperature
    D_KL = nn.KLDivLoss()(F.log_softmax(all_out/T, dim=1), F.softmax(teacher_all_out/T, dim=1)) * (T * T)
    return D_KL

def adjust_learning_rate(optimizer, lr, epoch):
    if epoch <= 50:
        for param_group in optimizer.param_groups:
            param_group["lr"] = lr * epoch / 50


def add_labels(feat, labels, idx, n_classes):
    onehot = torch.zeros([feat.shape[0], n_classes]).to(feat.device)
    onehot[idx, labels[idx, 0]] = 1
    return torch.cat([feat, onehot], dim=-1)


def train(model, data, train_idx, optimizer, arch, args, n_classes):
    model.train()

    optimizer.zero_grad()

    if args.use_label:
        mask = torch.rand(train_idx.shape) < args.mask_rate

        train_labels_idx = train_idx[mask]
        train_pred_idx = train_idx[~mask]
        
        x = add_labels(data.x, data.y, train_labels_idx, n_classes)
    
    else:
        mask = torch.rand(train_idx.shape) < args.mask_rate
        train_pred_idx = train_idx[mask]
        x = data.x

    pred = model(x, data.adj_t, arch)

    if args.label_iter > 0:
        unlabel_idx = torch.cat([train_pred_idx, data.valid_idx, data.test_idx])
        for _ in range(args.label_iter):
            pred = pred.detach()
            torch.cuda.empty_cache()
            x[unlabel_idx, -n_classes:] = F.softmax(pred[unlabel_idx], dim=-1)
            pred = model(x, data.adj_t, arch)

    if args.mode == 'student':
        # use distillation
        teacher_output = torch.load(args.path_teacher.replace("*", f"{args.cur_run}-{args.teacher_epoch[args.cur_run]}")).to(pred.device).softmax(dim=-1)
        if args.use_cs:
            from .cs import general_outcome_correlation
            teacher_output = general_outcome_correlation(args.graph, teacher_output, 2, 0.5, True, lambda x: x.clamp(0, 1))
        
        loss_ce = F.nll_loss(pred[train_pred_idx], data.y.squeeze(1)[train_pred_idx])
        loss_kd = loss_kd_only(pred, torch.log(teacher_output), args.T)
        loss = loss_ce * (1 - args.alpha) + loss_kd * args.alpha

    else:
        loss = F.nll_loss(pred[train_pred_idx], data.y.squeeze(1)[train_pred_idx])
    
    loss.backward()
    optimizer.step()

    return loss.item()


@torch.no_grad()
def test(model, x, y, adj, split_idx, evaluator, arch, args, n_classes):
    model.eval()

    if args.use_label:
        x = add_labels(x, y, split_idx['train'], n_classes)

    pred = model(x, adj, arch)
    
    if args.label_iter > 0:
        unlabel_idx = torch.cat([split_idx['valid'], split_idx['test']])
        for _ in range(args.label_iter):
            pred = pred.detach()
            torch.cuda.empty_cache()
            x[unlabel_idx, -n_classes:] = F.softmax(pred[unlabel_idx], dim=-1)
            pred = model(x, adj, arch)
    
    y_pred = pred.argmax(dim=-1, keepdim=True)

    train_acc = evaluator.eval({
        'y_true': y[split_idx['train']],
        'y_pred': y_pred[split_idx['train']],
    })['acc']
    valid_acc = evaluator.eval({
        'y_true': y[split_idx['valid']],
        'y_pred': y_pred[split_idx['valid']],
    })['acc']
    test_acc = evaluator.eval({
        'y_true': y[split_idx['test']],
        'y_pred': y_pred[split_idx['test']],
    })['acc']

    return pred, train_acc, valid_acc, test_acc

    
@torch.no_grad()
def test_only(pred, y, split_idx, evaluator):
    y_pred = pred.argmax(dim=-1, keepdim=True)

    train_acc = evaluator.eval({
        'y_true': y[split_idx['train']],
        'y_pred': y_pred[split_idx['train']],
    })['acc']
    valid_acc = evaluator.eval({
        'y_true': y[split_idx['valid']],
        'y_pred': y_pred[split_idx['valid']],
    })['acc']
    test_acc = evaluator.eval({
        'y_true': y[split_idx['test']],
        'y_pred': y_pred[split_idx['test']],
    })['acc']

    return pred, train_acc, valid_acc, test_acc
        
            
def main():
    parser = argparse.ArgumentParser(description='gen_models')
    parser.add_argument('--device', type=int, default=0)
    parser.add_argument('--log_steps', type=int, default=1)
    parser.add_argument('--num_layers', type=int, default=3)
    parser.add_argument('--hidden_channels', type=int, default=256)
    parser.add_argument('--use-node-embedding', action='store_true', default=True)
    parser.add_argument('--use-label', action='store_true', default=True)
    parser.add_argument('--label-iter', type=int, default=0)
    parser.add_argument('--mask-rate', type=float, default=0.7)

    parser.add_argument('--dropout', type=float, default=0.5)
    parser.add_argument('--lr', type=float, default=0.01)
    parser.add_argument('--epochs', type=int, default=500)
    parser.add_argument('--wd', type=float, default=0.0)
    parser.add_argument('--runs', type=int, default=10)
    parser.add_argument('--no-track', action='store_true')
    parser.add_argument('--archs', type=str, default=str(['gcn'] * 6))
    parser.add_argument('--arch-path', type=str, default='./models/arxiv/random_sample.pkl')
    parser.add_argument('--space', type=str, default='simple', choices=['simple', 'full'])
    parser.add_argument('--path', type=str, default='./models/arxiv/ablation-prediction-student/*.pt')
    parser.add_argument('--save', action='store_true')
    parser.add_argument('--mode', type=str, choices=['teacher', 'student'], default='teacher')
    parser.add_argument('--path-teacher', type=str, default='./models/arxiv/ablation-prediction/*.pt')
    # GCN
    parser.add_argument('--teacher-epoch', type=int, nargs='+', default=[237, 272, 218, 344, 210, 294, 205, 412, 222, 442])
    
    # GAUSS
    # parser.add_argument('--teacher-epoch', type=int, nargs='+', default=[138, 131, 149, 130, 138, 123, 132, 128, 115, 116])
    parser.add_argument('--alpha', type=float, default=0.95)
    parser.add_argument('--T', type=float, default=0.7)
    parser.add_argument('--use-cs', action='store_true')

    args = parser.parse_args()

    if args.mode == 'student' and args.use_cs:
        from .cs import load_data, preprocess
        args.graph = preprocess(load_data("ogbn-arxiv")[0]).to('cuda')

    args.space = ARXIV_SIMPLE
    args.arch = eval(args.archs)

    if isinstance(args.arch, int):
        args.arch = pickle.load(open(args.arch_path, 'rb'))[args.arch]
    print(args)

    
    device = f'cuda:{args.device}' if torch.cuda.is_available() else 'cpu'
    device = torch.device(device)

    dataset = PygNodePropPredDataset(name='ogbn-arxiv', root=os.path.expanduser("~/dataset/pyg"), transform=T.ToSparseTensor())
    
    data = dataset[0]
    data.adj_t = data.adj_t.to_symmetric()
    data = data.to(device)

    print('num features', data.x.size(1))
    print('num classes', dataset.num_classes)

    x = data.x
    if args.use_node_embedding:
        embedding = torch.load('models/arxiv/embedding.pt', map_location=device)
        x = torch.cat([x, embedding], dim=-1)

    data.x = x.to(device)
    adj_t = data.adj_t.to(device)
    y_true = data.y.to(device)

    split_idx = dataset.get_idx_split()
    train_idx = split_idx['train'].to(device)
    valid_idx = split_idx['valid'].to(device)
    test_idx = split_idx['test'].to(device)

    data.train_idx = train_idx
    data.valid_idx = valid_idx
    data.test_idx = test_idx

    n_input = x.size(-1)

    if args.use_label: n_input += dataset.num_classes

    model = Supernet(n_input, args.hidden_channels, dataset.num_classes, args.num_layers, args.dropout, space=args.space, arch=args.arch, track=not args.no_track).cuda()
        
    evaluator = Evaluator(name='ogbn-arxiv')
    logger = Logger(args.runs, args)
    
    for run in range(args.runs):
        args.cur_run = run
        print(sum(p.numel() for p in model.parameters()))
        
        model.reset_parameters()
        optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=args.wd)

        for epoch in range(1, args.epochs + 1):
            adjust_learning_rate(optimizer, args.lr, epoch)
            loss = train(model, data, train_idx, optimizer, args.arch, args, dataset.num_classes)
            result = test(model, x, y_true, adj_t, split_idx, evaluator, args.arch, args, dataset.num_classes)
            y_pred, train_acc, valid_acc, test_acc = result
        
            if args.path and args.save:
                torch.save(y_pred, args.path.replace('*', f'{run}-{epoch}'))

            print(f'Run: {run + 1:02d}, '
                      f'Epoch: {epoch:02d}, '
                      f'Loss: {loss:.4f}, '
                      f'Train: {100 * train_acc:.2f}%, '
                      f'Valid: {100 * valid_acc:.2f}% '
                      f'Test: {100 * test_acc:.2f}%')
            logger.add_result(run, result[-3:])
        
        logger.print_statistics(run)

    logger.print_statistics()

if __name__ == "__main__":
    main()