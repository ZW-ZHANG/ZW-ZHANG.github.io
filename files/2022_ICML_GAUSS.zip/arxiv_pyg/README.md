```cmd
CUDA_VISIBLE_DEVICES=1 python -m arxiv_pyg.train_simple --repeat 10 --eval-epoch 50 --save-epoch 25 --sampler-fit 25 --T 100 --use-sampler --iter-sampler 10 --restore-epoch 300 --restore-folder ./models/arxiv/supernet/ablation-SIM-simple-res-True-jk-True-3-repeat-10-pr-False-ratio-0.2-0.2-1.0-sbn-False-RANDOM/models --name ablation-rerun
```