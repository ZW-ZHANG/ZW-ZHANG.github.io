"""
Evaluate the given model
"""

import argparse
import os
import torch
import torch.nn.functional as F
import torch_geometric.transforms as T
from ogb.nodeproppred import PygNodePropPredDataset, Evaluator
from utils import Logger, read_all
from .supernet import Supernet, ARXIV, ARXIV_SIMPLE
import pickle
from tqdm import tqdm
from scipy.stats import kendalltau

@torch.no_grad()
def arch2score(arcs, data, model, evaluator, split_idx, gradient=False):
    assert not gradient
    model.eval()

    accs, losses = [], []
    for arch in tqdm(arcs):
        out = model(data.x, data.adj_t, arch)
        y_pred = out.argmax(dim=-1, keepdim=True)

        valid_acc = evaluator.eval({
            'y_true': data.y[split_idx['valid']],
            'y_pred': y_pred[split_idx['valid']],
        })['acc']
        
        accs.append(valid_acc)
        loss_val = F.nll_loss(out[split_idx["valid"]], data.y.squeeze(1)[split_idx["valid"]])
        losses.append(loss_val.item())

    return losses, accs, None
            
def main():
    parser = argparse.ArgumentParser(description='gen_models')
    parser.add_argument('--device', type=int, default=0)
    parser.add_argument('--num_layers', type=int, default=6)
    parser.add_argument('--hidden_channels', type=int, default=128)
    parser.add_argument('--use_node_embedding', action='store_true')

    parser.add_argument('--dropout', type=float, default=0.5)
    parser.add_argument('--track', action='store_true')
    parser.add_argument('--model', type=str)
    parser.add_argument('--space', type=str, default='simple', choices=['simple', 'full'])
    parser.add_argument('--number', type=int, default=300)
    parser.add_argument('--begin', type=int, default=0)
    parser.add_argument('--end', type=int, default=500)
    parser.add_argument('--interval', type=int, default=50)
    
    args = parser.parse_args()

    _name = args.space
    if args.space == 'full': args.space = ARXIV
    else: args.space = ARXIV_SIMPLE
    print(args)

    all_logs = read_all('./logs/arxiv/baseline/', end=args.number, prefix='simple-' if _name == 'simple' else '')
    archs = list(map(lambda x:x[0], all_logs))
    vals = list(map(lambda x:x[1], all_logs))
    tests = list(map(lambda x:x[2], all_logs))
    
    device = f'cuda:{args.device}' if torch.cuda.is_available() else 'cpu'
    device = torch.device(device)

    dataset = PygNodePropPredDataset(name='ogbn-arxiv', root=os.path.expanduser("~/dataset/pyg"), transform=T.ToSparseTensor())
    
    data = dataset[0]
    data.adj_t = data.adj_t.to_symmetric()
    data = data.to(device)
    
    x = data.x
    if args.use_node_embedding:
        embedding = torch.load('embedding.pt', map_location=device)
        x = torch.cat([x, embedding], dim=-1)
        
    x = x.to(device)
    adj_t = data.adj_t.to(device)
    y_true = data.y.to(device)
    
    split_idx = dataset.get_idx_split()
    train_idx = split_idx['train'].to(device)
    valid_idx = split_idx['valid'].to(device)
    test_idx = split_idx['test'].to(device)

    model = Supernet(x.size(-1), args.hidden_channels, dataset.num_classes, args.num_layers, args.dropout, args.space, track=args.track).cuda()

    losses = []
    vales = []
    for i in range(args.begin, args.end + 1, args.interval):
        model.load_state_dict(torch.load(args.model.replace('0.pt', f'{i}.pt')))
        evaluator = Evaluator(name='ogbn-arxiv')

        my_loss, my_val, _ = arch2score(archs, data, model, evaluator, split_idx)
        print(kendalltau(my_loss, vals)[0], kendalltau(my_val, vals)[0], kendalltau(my_loss, tests)[0], kendalltau(my_val, tests)[0])
        losses.append(-kendalltau(my_loss, vals)[0])
        vales.append(kendalltau(my_val, vals)[0])
    print('losses', losses)
    print('vales', vales)

if __name__ == "__main__":
    main()