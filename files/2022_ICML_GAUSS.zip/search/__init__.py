from tqdm import tqdm

class EvolutionAlgorithm:
    def __init__(self, uniform_generator, mutator, arch2score, initial_population=500, epochs=5, mut_population=100):
        self.uniform_generator = uniform_generator
        self.mutator = mutator
        self.arch2score = arch2score
        self.initial_population = initial_population
        self.epochs = epochs
        self.mut_population = mut_population
    
    def search(self):
        """search in the given settings

        Returns:
            List[Tuple(archs, performance)]: Sorted performance list
        """
        population = []
        while len(population) < self.initial_population:
            archs = self.uniform_generator()
            if archs not in population:
                population.append(self.uniform_generator())
        
        # eval the accs
        performance = self.arch2score(population)
        binded = [(p, a) for p, a in zip(population, performance)]
        binded = sorted(binded, key=lambda x:x[1])

        for _ in range(self.epochs):
            # we first get the top k archs and mutate them
            current_archs = [x[0] for x in binded]
            current_len = len(current_archs)
            pointer = 0
            while len(current_archs) < current_len + self.mut_population:
                arch = self.mutator(current_archs[pointer])
                if arch not in current_archs:
                    current_archs.append(arch)
                pointer += 1
            
            new_archs = current_archs[current_len:]

            # get the performances
            performance = self.arch2score(new_archs)
            binded += [(p, a) for p, a in zip(new_archs, performance)]
            binded = sorted(binded, key=lambda x:x[1])

        return binded
